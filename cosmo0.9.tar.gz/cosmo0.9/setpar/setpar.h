bool setpar_chk (int argc, char *argv[], const char *opt) ;
int setpar_i (int argc, char *argv[], const char *opt, int d, int mn, int mx, FILE *fp) ;
double setpar_f (int argc, char *argv[], const char *opt, double d, double mn, double mx, FILE *fp) ;
int setpar_slen (int argc, char *argv[], const char *opt, FILE *fp) ;
char *setpar_s (int argc, char *argv[], const char *opt, FILE *fp) ;
int setpar_find_opt_pos (int argc, char *argv[], const char *opt) ;
bool setpar_chk_opt_called_twice (int argc, char *argv[], FILE *fp) ;