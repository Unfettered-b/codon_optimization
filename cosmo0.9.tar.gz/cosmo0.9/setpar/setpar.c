#include <stdlib.h> 
#include <string.h> 
#include <stdio.h> 

#include "setpar.h"

bool setpar_chk (int argc, char *argv[], const char *opt) {
// returns whether opt is included in argv or not.
// (note: even if the same opt is found twice, this routine returns True).
   if (setpar_find_opt_pos(argc, argv, opt) != argc) { 
      printf("%s YES\n", opt);
      return true ;
   } else { 
      printf("%s NO\n", opt);
      return false ;
   }
}

int setpar_i (int argc, char *argv[], const char *opt, int d, int mn, int mx, FILE *fp) {
// returns [int] when "opt [int]" is found in argv.
// needs stdlib.h.
   int i, a ;
   if ( (i = setpar_find_opt_pos (argc, argv, opt)) != argc ) {
      if (i + 1 < argc) {
         a = atoi(argv[i + 1]) ;
         if (mn <= a && a <= mx)  { 
            printf ("%s %d\n", opt, a) ;
            return a ;
         } else {
            fprintf (fp, "ERROR: option %s %s should be >= %d & <= %d.\n", 
                     argv[i], argv[i + 1], mn, mx) ; 
            exit(1) ;
        }
      }
   }

   printf ("%s %d\n", opt, d) ;
   return d ; // if not find, returns the default value.
}

double setpar_f (int argc, char *argv[], const char *opt, double d, double mn, double mx, FILE *fp) {
// returns [float] when "opt [flaot]" is found in argv.
// needs stdlib.h.
   int i ;
   double a ;
   if ( (i = setpar_find_opt_pos(argc, argv, opt)) != argc ) {
      if (i + 1 < argc) {
         a = atof(argv[i + 1]) ;
         if (mn <= a && a <= mx) {
            printf ("%s %f\n", opt, a) ;
            return a ;
         } else { fprintf (fp, "ERROR: option %s %s should be >= %f & <= %f.\n", 
                           argv[i], argv[i + 1], mn, mx) ; 
               exit(1) ; }
      }
   }

   printf ("%s %f\n", opt, d) ;
   return d ; // if not find, returns the default value.
}

int setpar_slen (int argc, char *argv[], const char *opt, FILE *fp) {
// returns the length of the string next to opt. if not found, returns 0.
// needs string.h.
   int i ;
   if ( (i = setpar_find_opt_pos(argc, argv, opt)) != argc ) {
      if (i + 1 < argc) return strlen(argv[i + 1]) ;
   }
   return 0 ;
}

char *setpar_s (int argc, char *argv[], const char *opt, FILE *fp) {
// returns the pointer to the string next to opt. if not find, returns NULL.
// needs stdlib.h.
// usage ex.:
//   if ( (l = setpar_slen (argc, argv, opt, stderr)) == 0 ) {
//      fprintf (fp, "ERROR: option %s has an error.\n", opt) ; 
//      exit(1) ;
//   }
//   s = (char *)calloc(sizeof(char), l + 1) ;
//   strcpy (s, setpar_s(argc, argv, opt, stderr)) ;
   int i ;
   if ( (i = setpar_find_opt_pos(argc, argv, opt)) != argc ) {
      if (i + 1 < argc) return argv[i + 1] ;
   }
   return NULL ;
}

int setpar_find_opt_pos (int argc, char *argv[], const char *opt) {
// returns the position of a specified option in argv. Position index starts with 0.
// if not found, returns argc. 
// note: if the same option is called twice, the position of the first one is returned.
// needs string.h.
   int i ;
   // option name check: check '-' at the top of the opt.
   if (opt[0] == '-') { 
      for (i = 0 ; i < argc ; i++) {
         if (strcmp(argv[i], opt) == 0) return i ;
      }
   }
   return argc ;
}

bool setpar_chk_opt_called_twice (int argc, char *argv[], FILE *fp) {
// checks whether the same option is called twice in argv.
// when there is an option called twice, returns true, otherwise false.
// needs string.h and basic_def.c.
   int i, j ;
   // option name check: checks a '-' at the 1st letter of the opt.
   for (i = 0 ; i < argc ; i++) {
      if (argv[i][0] == '-') { 
         for (j = i + 1 ; j < argc ; j++) {
            if (argv[j][0] == '-') { 
                if (strcmp(argv[i], argv[j]) == 0) {
                   fprintf (fp, "ERROR: %s is called multiple times.\n", argv[i]) ; 
                   return true ;
                }
            }
         }
      }
   }
   return false ; 
}
