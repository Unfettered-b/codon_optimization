
using namespace std ;

class score {
   int nsc ;
   vector<double> sc ;
   int bt ; // codon index of one aa position
   list<score>::iterator pre ; // not initialized
   vector<bool> maximize ;
   vector<double> sc4wsum ;
   int icai  ;
   double caiVal ;
public:
   score (const score &obj) { 

      nsc = obj.nsc ;

      sc =obj.sc ; 
      maximize = obj.maximize ; 
      sc4wsum = obj.sc4wsum ; 
      icai = obj.icai ;
      caiVal = obj.caiVal ;
   } 
   score (int n, double *x, vector<bool> &maxi) { 
      int i ;
      nsc = n ;

      bt = 0 ;
      maximize = maxi ; 

      for (i = 0 ; i < n ; i++)         
         { if (maximize[i]) sc.push_back(x[i]) ; else sc.push_back(-x[i]) ; }
      icai = 999 ;
      caiVal = 999 ;
   } 
   score (int n, double *x, vector<bool> &maxi, double *y) {
      int i ;
      nsc = n ;

      bt = 0 ;
      maximize = maxi ; 

      for (i = 0 ; i < n ; i++)           
         { if (maximize[i]) sc.push_back(x[i]) ; else sc.push_back(-x[i]) ; }
      for (i = 0 ; i < 3 ; i++) sc4wsum.push_back(y[i]) ;

      icai = 999 ;
      caiVal = 999 ;
   } 

   void set (int i, double x) { if (maximize[i]) sc[i] = x ; else sc[i] = -x ; }
   double getSc (int i) { if (maximize[i]) return sc[i] ; else return -sc[i] ; }
   void add (int i, double x) { if (maximize[i]) sc[i] += x ;  else sc[i] += -x ; }

   double getSc4wsum (int i) { return sc4wsum[i] ; } 
   void add4wsum (int i, double x) { sc4wsum[i] += x ; }

   double get (int i) { 
      if (i == icai) return caiVal ; 
      else return sc[i] ;
   } 
   void set_bt (int i) { bt = i ; }
   int get_bt () { return bt ; }
   void set_it (list<score>::iterator iter) { pre = iter ; }
   list<score>::iterator get_it () { return pre ; }
   bool operator<(score &obj) {
      // For the sort in LEXICOGRAPHIC order;
      // each alphabet is a double-precision floating-point number.
      int i ;

      for (i = 0 ; i < obj.nsc ; i++) { // LEXICOGRAPHIC order 
         if (i == icai) {
            if (caiVal < obj.caiVal) return true ; // for the sort in ascending order by .sort()
            else if (caiVal > obj.caiVal) return false ;
         } else {
            if (sc[i] < obj.sc[i]) return true ; // for the sort in ascending order by .sort()
            else if (sc[i] > obj.sc[i]) return false ;
         }
      }
      return false ;
   }
   void print_all () {  
      int i ;
      for (i = 0 ; i < nsc ; i++) 
         if (maximize[i]) cout << sc[i] << " " ;
         else             cout << -sc[i] << " " ;
      cout <<  endl ;
   }
   void setCaiVal (int i, double x) { icai = i ; if(maximize[i]) caiVal = (float)x ; else caiVal = -(float)x ; }
   double getCaiVal () { if (maximize[0]) return caiVal ; else return -caiVal ; }
} ;

void sorted_splice (list<score> &lst, list<score> &lstL, list<score> &lstH) ;
void singleOF (list<score> &lst) ;
void twoOFs (list<score> &lst) ;
void simpleComparison4Merge (list<score> &lstA, list<score> &lstB, int nx) ;

