# gc-filter.py: A script for filtering the COSMO output.
#
# Usage: 
#  First, redirect cosmo's stdout to a file (in the following, cosmo.out).
#  If the user is interested in designed CDSs with GC-content from 40% to 60%; 
#    python3.6 gc-filter.py  cosmo.out 40 60
#
#  In addition, the dG of the 3'-region of the CDS can be computed by RNAfold (if already installed):
#    python3.6 gc-filter.py cosmo.out 40 60  "" 20
#
#  The following command will evaluate the dG of "ACCGCG" + the 5'-region of the CDS with 20 nucleotides:
#    python3.6 gc-filter.py cosmo.out 40 60  "ACCGCG" 20
#  

import RNA # If the Vienna RNA Package is not installed, comment out this line.
import sys
import re
import math
from decimal import Decimal, ROUND_HALF_UP

def EuclidDist (o, ma, mi, maxmi, so, no): 
   dist = 0.0
   eachD = []
   for i in range(no):
      width = ma[i] - mi[i]
      if maxmi[i] == "max)":
         d = ( (so[i] - mi[i] )/width - (o[i] - mi[i] )/width )**2
      elif maxmi[i] == "min)":
         d = ( ( (-so[i]) - (-ma[i]) )/width - ( (-o[i]) - (-ma[i]) )/width)**2
      else:
         print ("ERROR")
         sys.exit(0)
      eachD.append(math.sqrt(d))
      dist += d 

   dist = math.sqrt(dist)
   return [dist,eachD]

def gccont(seq) :
    return 100.0*float(seq.count('G')+seq.count('C'))/float(len(seq))

def addln ():
   # GC content check
   if gccont(line[1]) >= gclow and gccont(line[1]) <= gchigh:
      #dG
      sq = utrSeq + line[1][:foldCDSLen]
      (ss, mfe) = RNA.fold(sq) # If the Vienna RNA Package is not installed, comment out this line and use the following line instead of this line.
#                  (ss, mfe) = ("..",0) 
      ln0.append(line[0])
      ln1.append(line[1])
      dg.append(mfe)
      gc.append(gccont(line[1]))

print ("# outFile= ", sys.argv[1])

gclow=int(sys.argv[2])
gchigh=int(sys.argv[3])
print ("# LowestGCcont= ", gclow)
print ("# HighestGCcont= ", gchigh)

numOutputSol=int(sys.argv[4])

utrSeq = ''
foldCDSLen=30 # a default value
if len(sys.argv)>=7:
  utrSeq=sys.argv[5]
  foldCDSLen=int(sys.argv[6])

print ("# utrSeq= ", utrSeq)
print ("# foldLen= ", foldCDSLen)

flag = 'n'
gc=[]
ln0=[]
ln1=[]
dg=[]
flag2 = False
maxmin = []
#ofname = []
min = []
max = []
with open(sys.argv[1],"r") as f:
    for x in f:
        y=x.rstrip()
        if re.compile("^Solution").search(y):
            flag = 'y'
            line = []
            line.append(y)
        elif re.compile("^\s*$").search(y):
            if flag is 'y':
               addln()
            flag = 'n'

        elif re.compile("^#MAX&MIN").search(y):
           y = x.split()
           nof = int(y[2])
           for z in y[3:]:
              a = z.split('(')
              maxmin.append(a[1])
              #ofname.append(a[0])
           flag2 = True

        elif flag2 == True:
           y = x.split()
           max.append(float(y[0]))
           min.append(float(y[1]))
           if len(max) == nof :
              flag2 = False

        else:
            if flag is 'y':
                line.append(y)
    addln()

if numOutputSol <= 0:
    numOutputSol = len(ln1)

idealOF = []
for i in range(len(maxmin)):
    if maxmin[i] == "max)":
        idealOF.append(max[i]) 
    elif maxmin[i] == "min)":
        idealOF.append(min[i]) 
    else:
        print ("ERORR")
        sys.exit(0)

if  len(ln0)==0:
    print("No sequences are outout.")
    sys.exit(0)

dist = []
eachDimDist = []
for ofs in ln0:
    x = [float(a) for a in ofs.split()[3:3+nof]]
    d, edist = EuclidDist (idealOF, max, min, maxmin, x, nof)
    dist.append(d)
    eachDimDist.append(edist)

sortedDist = sorted(dist)
cutoff = sortedDist[numOutputSol - 1]

num = 0
#for ofs,seq,e,cont,d,ecd in zip(ln0,ln1,dg,gc,dist,eachDimDist):
for ofs,seq,e,cont,d in zip(ln0,ln1,dg,gc,dist):
  if d <= cutoff and num < numOutputSol:
   print (ofs)
   print (seq)
   print ("# dG= ", str(f'{e:.3f}')) # If the Vienna RNA Package is not installed, comment out this line.
   print ("# GCCONT= ", str(f'{cont:.1f}'))
   print ("# DIST_NEAREST_PARETO_SOL= ", str(f'{d:.5f}'))
   #for on, e in zip(ofname,ecd):
   #   print ("# EACH_DIM_DIST_NEAREST_PARETO_SOL (", on, ")= ", Decimal(str(e)).quantize(Decimal('0.00001'), rounding=ROUND_HALF_UP))
     
   print()
   num += 1

# Entropy for sequence conservation check
entropyAllPositions = 0.0
tot=len(ln1[0])
consSq=''
for i in list(range(0,len(ln1[0]))):
   acgu=[0,0,0,0]
   #for sq in ln1:
   num = 0
   for j in range(len(ln1)):
      sq = ln1[j]
      if dist[j] <= cutoff and num < numOutputSol:
       if sq[i] is 'A':
           acgu[0]+=1 
       elif sq[i] is 'C':
           acgu[1]+=1 
       elif sq[i] is 'G':
           acgu[2]+=1 
       elif sq[i] is 'U':
           acgu[3]+=1 
       elif sq[i] is 'T':
           acgu[3]+=1 
       num += 1
   ent = 0.0
   for j in range(4):
       p = float(acgu[j])/float(num)
       if p != 0.0:
          ent += -p*math.log2(p)
   entropyAllPositions += ent
   if ent==0.0:
       consSq += '0'
   else:
       consSq += str(math.ceil(4*ent))
print("# Sequence conservation indicator for each nucleotide position calculated by ceil(4log2(entropy)) (0:zero entropy, 8:p_A = p_C = p_G = p_U = 0.25):")
print(consSq)
print()
entropyAllPositions /= len(ln1[0]) 
print ("# Mean_entropy_over_all_positions= ",str(f'{entropyAllPositions:.3f}'))