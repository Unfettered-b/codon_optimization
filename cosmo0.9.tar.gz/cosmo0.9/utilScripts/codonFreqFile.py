# codonFreqFile.py: A script for extracting the codon usage and 
# codon pair usage from CoCoPUTs .tsv files that are downloaded 
# at the CoCoPUTs website (note: the CoCoPUTs .tsv files used in 
# the following exapmles are very larage files including over 10 GBytes).
#
# Usage: 
#  If the user needs codon usage frequency file of "Saccharomyces 
#  cerevisiae genomic", type the follwing command:
#    python3 ./codonFreqFile.py  yeast.cu o586358-genbank_species.tsv "Saccharomyces cerevisiae\tgenomic"
#
#  If the user needs codon pair usage frequency file of "Saccharomyces
#  cerevisiae genomic", type the follwing command:
#    python3 ./codonFreqFile.py  yeast.cu o586358-genbank_Bicod.tsv   "Saccharomyces cerevisiae\tgenomic"
#
#  These commands will generate .cu and .cpu files that are accepbable 
#  as the input files for COSMO.

import sys
import re

# read a codon-amino acid table like yeast.cu
aa = {}
with open(sys.argv[1],"r") as f:
    for x in f:
        #cu=x.translate(str.maketrans("T","U")).split()
        cu=x.split()
        cu1 = cu[1].translate(str.maketrans("T","U"))
        aa[cu1] = cu[0]
        #aa[cu[1]] = cu[0]

with open(sys.argv[2],"r") as f:
    codon = []
    for x in f:
        y=x.rstrip()
        if re.compile("^Division").search(y):
            q=y.translate(str.maketrans("Tacgt","UACGU")).split("\t")
            if re.compile("Codon Pairs").search(y):
                pair='y'
                codon=q[8:]
            else:
                pair='n'
                codon=q[12:]
        elif not re.compile(sys.argv[3]).search(y):
            continue
        elif re.compile("^refseq").search(y) or re.compile("^genbank").search(y):
            if pair is 'n':
               q = y.split("\t") 
               freq = [int(v) for v in q[12:]]
               table = dict(zip(codon,freq)) 
               sum={}
               for cod,fr in table.items():
                   if aa[cod] in sum:
                      sum[aa[cod]] += fr
                   else:
                      sum[aa[cod]] = fr
               # output here
               f = open(q[1]  + '-' + q[2] + '-' + q[3].translate(str.maketrans(" ","_")) + ".cu", "w")
               for cod,fr in table.items():
                   if sum[aa[cod]] == 0:
                      rate=0.0
                   else:
                      rate=float(fr)/float(sum[aa[cod]])
                   print (aa[cod]  + ' ' + cod, rate, fr, file=f)
               f.close()

            else:  # codon pair
               q = y.split("\t") 
               freq = [int(v) for v in q[8:]]
               table = dict(zip(codon,freq)) 
               sum={}
               for codp,fr in table.items():
                   b=aa[codp[:3]]+aa[codp[3:]]
                   if b in sum:
                      sum[b] += fr
                   else:
                      sum[b] = fr
               # output here
               f = open(q[1]  + '-' + q[2] + '-' + q[3].translate(str.maketrans(" ","_")) + ".cpu", "w")
               for codp,fr in table.items():
                   if aa[codp[:3]] == '*':
                       continue
                   b=aa[codp[:3]]+aa[codp[3:]]
                   if sum[b] == 0:
                      rate=0.0
                   else:
                      rate=float(fr)/float(sum[b])
                   print ( aa[codp[:3]] + ' ' + codp[:3] + ' ' + aa[codp[3:]] + ' ' + codp[3:], rate, fr, file=f)
               f.close()