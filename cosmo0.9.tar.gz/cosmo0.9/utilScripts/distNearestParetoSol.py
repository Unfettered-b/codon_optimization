# distNearestParetoSol.py: A script to compute the normalized distance in 
#  the objective space between an input CDS and the Pareto-optimal CDSs 
#  that code for the amino acid sequence same with the input CDS.
#
# Usage: 
#  First, run COSMO with an input CDS (not with an amino acid sequence), and
#  redirect cosmo's stdout to a file (in the following, cosmo.out):
#     E.g. cosmo -f example.cds  > cosmo.out
#  Then, type the following command:
#  python3.6 distNearestParetoSol.py cosmo.out

import math
import sys
import re

def EuclidDist (o, ma, mi, maxmi, so, no): 
   dist = 0.0
   eachD = []
   for i in range(no):
      width = ma[i] - mi[i]
      if maxmi[i] == "max)":
         d = ( (so[i] - mi[i] )/width - (o[i] - mi[i] )/width )**2
      elif maxmi[i] == "min)":
         d = ( ( (-so[i]) - (-ma[i]) )/width - ( (-o[i]) - (-ma[i]) )/width)**2
      else:
         print ("ERROR")
         sys.exit(0)
      eachD.append(math.sqrt(d))
      dist += d 

   dist = math.sqrt(dist)
   return [dist,eachD]

of = []
maxmin = []
ofname = []
ofval = {}
sol = []
solID = []
flag = False
min = []
max = []

with open(sys.argv[1],"r") as f:
   for x in f:
        x.strip()
        if re.compile("^CAI:").search(x):
           y = x.split(':')
           ofval["CAI"] = float(y[1]) 

        elif re.compile("^CAB:").search(x):
           y = x.split(':')
           ofval["CPB"] = float(y[1]) 

        elif re.compile("^HSC:").search(x):
           y = x.split(':')
           ofval["HSC"] = float(y[1])

        elif re.compile("^#MAX&MIN").search(x):
           y = x.split()
           nof = int(y[2])
           for z in y[3:]:
              a = z.split('(')
              of.append(ofval[a[0]])
              ofname.append(a[0])
              maxmin.append(a[1])
              flag = True

        elif flag == True:
           y = x.split()
           max.append(float(y[0]))
           min.append(float(y[1]))
           if len(max) == nof :
              flag = False

        elif re.compile("^Solution=").search(x):
           y = x.split()
           sol.append([float(z) for z in y[3:3+nof]])
           solID.append(int(y[1]))

minDist = math.sqrt(2)
nearSol = -1
for t,iSol in zip(sol,solID):
   edist = []
   dist, edist = EuclidDist (of, max, min, maxmin, t, nof)

   if len(sys.argv) > 2:
      print ("dist (Solution="+ str(iSol)  + ")= " + str(dist))
   if dist < minDist:
      minDist = dist
      minEDist = edist
      nearSol = iSol

print ("The normalized distance between the solution and the Pareto-optimal solution nearest to the solution= ", f'{minDist:.6f}')
for on, e in zip(ofname,minEDist):
   print ("Each dimension's component of the normalized distance= (", on, ")= ", str(f'{e:.6f}'))
print ("The Pareto-optimal solution nearest to the solution= Solution", str(nearSol))