#include <iostream>
#include <list>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <boost/xpressive/xpressive.hpp>
#include <boost/foreach.hpp>
#include <boost/algorithm/string.hpp>

using namespace std;
using namespace boost::xpressive;

#include "codon/codon.h"
#include "maxima.h"
#include "setpar/setpar.h"

class chain {
   // These values are set once int set(), thereafter not changed.
   char aa ; // An amino acid code
   int aapos ; // An amino acid position (0-base)
   int nCodType ; // #synonymous codons of the aa
   int mCodType ; // max. #indexes for multiple continuous codons
   int mcods ;    // the parameter k (= mcods+1) for multiple continuous codons (note: aapos dependent)
   int aalen ;
   int nsc ;
   vector<bool> ofb ;
   vector<double> constraint ;

   vector<double> weight ;
   bool dupliCheck ;
   vector<bool> constraintb ;
   bool simpleMaxima ; 
   bool verboseOut ;
   sregex forbiddenPat ;
   bool forbiddenPatOn ;

   list<score> *lst ; // An array whose elements are lists. lst[x] contains the non-dominated 
                      //   solutions  V_{c_{i-k+1}...c_i}^i, where x is an index corresponds to  
                      //   an codon assignment for c_{i-k+1}...c_i, and i = aapos + 1.
public:
   void set (int l, vector<string> of, vector<double> c, vector<double> w, bool dc, vector<bool> co, bool sm, bool vpo) ; // For parameter settings

   void set (int pos, chain *cha) ; // For the final Pareto-optimal solutions
   void set (int pos, char amino, int mcodons, chain *cha, string pat, vector<bool> maximize) ;
   void setCod (int icod, vector<bool> maximize) ;
   void setCodA (int icod, chain *cha) ;
   void setCodB (int icod, chain *cha, vector<bool> maximize) ;
   void get_icd (int icode, vector<int> &icd, chain *cha) ;

   int get_icd_zero (int icode, chain *cha) ;
   int get_cod (vector<int> &jcd, chain *cha) ;
   list<score>::iterator get_begin (int i) { return lst[i].begin() ; }
   list<score>::iterator get_end (int i) { return lst[i].end() ; }
   bool forbiddenPatIncluded (vector<int> &icd, chain *cha) ;
   void print (int icod) {

      list<score>::iterator it ;
      for (it = lst[icod].begin() ; it != lst[icod].end() ; it++) 
         it->print_all () ;
   }

   ~chain() { delete [] lst ; }  

} ;

class dp {
   string aastr ; // aa char
   int aalen ;
   chain *cha ;
public:
   void dpmain (char *aaseq, string pat, vector<string> of, vector<bool> maximize, vector<double> constraint, vector<double> weight, bool dupliCheck, vector<bool> constraintb, bool simpleMaxima, bool verboseOut) ;

   ~dp () { delete [] cha ;}
};

void chain::set (int l, vector<string> of, vector<double> c, vector<double> w, bool dc, vector<bool> co, bool sm, bool vpo) {
   aalen = l ; constraint = c ; weight = w ; dupliCheck = dc ;  constraintb = co ;
   simpleMaxima = sm ; verboseOut = vpo ;
   nsc = of.size() ;
   ofb.insert(ofb.end(), 4, false) ;
   BOOST_FOREACH (string s, of) {
      if (s == "CAI") ofb[0] = true ;
      else if (s == "CPB") ofb[1] = true ;
      else if (s == "HSC") ofb[2] = true ;
      else if (s == "wsum") ofb[3] = true ;

      else { cout << "ERROR" << endl ; exit(0) ; }
   }
}

void chain::set (int pos, chain *cha)  { // For the final Pareto-opt. solutions

   aapos = pos ; aa = 'X' ;

   nCodType = 1 ;
   lst = new list<score> [nCodType] ;
   list<score>::iterator it, jt ;
   int jcod ;

   // Check all lists are empty or not
   bool empty = true ; 
   for (jcod = 0 ; jcod < cha[aapos - 1].mCodType ; jcod++)
      if ( !cha[aapos - 1].lst[jcod].empty() ) { empty = false ; break ; }

   if ( empty ) {
      cout << "No Pareto-optimal solution is found." << endl ;
      exit (0) ;
   }

   lst[0] = cha[aapos - 1].lst[jcod] ; // jcod is the 1st non-empty lst of the previous aapos ; copy
   jt = cha[aapos - 1].lst[jcod].begin() ;
   for (it = lst[0].begin() ; it != lst[0].end() ; it++) {

      it->set_bt ( cha[aapos - 1].get_icd_zero (jcod, cha) ) ; // Set a codon index of aapos-1 & jcod
      it->set_it (jt) ; jt++ ;
   }

   for (jcod++ ; jcod < cha[aapos - 1].mCodType ; jcod++) { 

      // Check whether a non-empty list or not
      if ( cha[aapos - 1].lst[jcod].empty() ) continue ;

      list<score> lstNext ;
      lstNext = cha[aapos - 1].lst[jcod] ; 

      jt = cha[aapos - 1].lst[jcod].begin() ;
      for (it = lstNext.begin() ; it != lstNext.end() ; it++) {
         it->set_bt ( cha[aapos - 1].get_icd_zero (jcod, cha) ) ; // Set a codon index of aapos-1 & jcod
         it->set_it (jt) ; jt++ ;
      }

      if (simpleMaxima) {
         simpleComparison4Merge (lst[0], lstNext, nsc) ;
         simpleComparison4Merge (lstNext, lst[0], nsc) ;
      }

      list<score> lstTmp ;
      sorted_splice (lstTmp, lst[0], lstNext) ; // Lexicographical merge.
      lst[0].splice (lst[0].end(), lstTmp) ;

      // Call helperA

      if (lst[0].empty()) { cout << "!" << endl; }
      if (!simpleMaxima) {
         if (nsc == 1) singleOF (lst[0]) ;
         else if (nsc == 2) twoOFs (lst[0]) ;
         else  { cout << "ERROR: #OFs >= 3 is not implemented.\n" ; exit(1) ; } ; 

      }
   }

   if (dupliCheck) {
      // Erase duplicate solutions if the OF values are the same with those of begin(). 
      list<score>::iterator preit = lst[0].begin() ;
      int nsame = 0 ;
      for (it = lst[0].begin() ; it != lst[0].end() ; ) {
         bool same = false ;
         if (it != lst[0].begin()) {
            same = true ;
            int i = 0 ;

            if (ofb[0]) { if (it->getCaiVal() != preit->getCaiVal()) same = false ; i++ ; }
            if (ofb[1]) { if (it->getSc(i) != preit->getSc(i)) same = false ; i++ ; }
            if (ofb[2]) { if (it->getSc(i) != preit->getSc(i)) same = false ; i++ ; }
            if (ofb[3]) { if (it->getSc(i) != preit->getSc(i)) same = false ; }
            if (same) nsame++ ;
         }
         if (same) it = lst[0].erase (it) ;
         else { preit = it ; it++ ; }
      }
   }
}

void chain::set (int pos, char amino, int mcodons, chain *cha, string pat, vector<bool> maximize)  {

   aapos = pos ; aa = amino ;
   if (pat.size() == 0) forbiddenPatOn = false ; 
   else { forbiddenPat = sregex::compile(pat) ; forbiddenPatOn = true ; }
   nCodType = codon_get_codonmax (aa) ;
   mCodType = 1;
   int i ;
   for (i = 0 ; i <= aapos && i <= mcodons ; i++) mCodType *= cha[aapos - i].nCodType ;

   lst = new list<score> [mCodType] ; 
   if (aapos == 0) { // The first element of cha[] (the start codon) 

      cout << "#OFs= " << nsc ; 
      if (ofb[0]) cout << " CAI";
      if (ofb[1]) cout << " CPB" ;
      if (ofb[2]) cout << " HSC" ;
      if (ofb[3]) cout << " wsum" ;
      cout << endl << endl ;
      mcods = 0 ; // not used 
      for (i = 0 ; i < mCodType ; i++) setCod (i, maximize) ; 
   } else if (aapos <= mcodons) { // 1 <= aapos <= mcodons (="the parameter k" - 1)

      mcods = aapos ; 
      for (i = 0 ; i < mCodType ; i++) setCodA (i, cha) ;

   } else { // mcodons (="the parameter k" - 1) < aapos  

      mcods = mcodons ; 
      for (i = 0 ; i < mCodType ; i++) setCodB (i, cha, maximize) ;

   }
}

bool chain::forbiddenPatIncluded (vector<int> &icd, chain *cha) {

// Note: the 1st codon is not checked. This check is applied in setCodA & B. 
   if (!forbiddenPatOn) return false ;
   int i ;
   int m = icd.size() - 1 ;
   string s = "" ; 
   for (i = m ; i >= 0 ; i--) s += codon_get_triplet (cha[aapos - i].aa, icd[i]) ;
   smatch match ;
   if ( regex_search (s, match, forbiddenPat ) ) return true ;
   return false ;  
}

void chain::setCod (int icod, vector<bool> maximize) {
// Set lst[icod] of aapos == 0 (the start codon).

   vector<bool> maxi ;
   double *val ; 

   val = new double [nsc] ;
   int i = 0 ;
   if (ofb[0]) { val[i++] = codon_get_CAI_value (aa, icod) ; maxi.push_back(maximize[0]) ; }
   if (ofb[1]) { val[i++] = 0.0 ; maxi.push_back(maximize[1]) ; } // CPB_value
   if (ofb[2]) { val[i++] = 0.0 ; maxi.push_back(maximize[2]) ; } // HSC_value
   if (ofb[3]) { val[i] = weight[0]*codon_get_CAI_value (aa, icod) ; maxi.push_back(maximize[3]) ; }

   if (ofb[3]) {
      double *val2 ;
      val2 = new double [3] ;
      val2[0] = codon_get_CAI_value (aa, icod) ; 
      val2[1] = 0.0 ; // CPB_value
      val2[2] = 0.0 ; // HSC_value
      lst[icod].push_back(score(nsc, val, maxi, val2)) ; // Maximization or minimization is defined here for each score. This information is copied to the lst elements at the subsequent aa positions.
      delete [] val2 ;
   } else lst[icod].push_back(score(nsc, val, maxi)) ; // Maximization or minimization is defined here for each score. This information is copied to the lst elements at the subsequent aa positions.

   if (ofb[0]) { lst[icod].begin()->setCaiVal( 0, pow(exp(val[0]),1.0/((double)(aapos + 1)) ) ) ; }

   delete [] val ;
}

void chain::setCodA (int icod, chain *cha) {
// Set lst[icod]. For 1 <= aapos <= mcodons (="the parameter k" - 1) (ie 2 <= i <= k).
   char bb = cha[aapos - 1].aa ;
   vector<int> icd, jcd ; 

   get_icd (icod, icd, cha) ; 
   if ( forbiddenPatIncluded (icd, cha) ) return ; 
   int i ;
   for (i = 1 ; i <= mcods ; i++) jcd.push_back(icd[i]) ;
   if (cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].empty() ) return ; 
   lst[icod] = cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ] ; 
   i = 0 ;
   if (ofb[0]) lst[icod].begin()->add( i++, codon_get_CAI_value (aa, icd[0]) ) ;
   if (ofb[1]) lst[icod].begin()->add( i++, codon_get_CPS_value (bb, icd[1], aa, icd[0]) ) ;
   if (ofb[2]) lst[icod].begin()->add( i++, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
   if (ofb[3]) lst[icod].begin()->add( i,
                              weight[0]*codon_get_CAI_value (aa, icd[0])
                            + weight[1]*codon_get_CPS_value (bb, icd[1], aa, icd[0])
                            + weight[2]*codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;

   lst[icod].begin()->set_bt (jcd[0]) ;
   lst[icod].begin()->set_it ( cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].begin() ) ;

   if (ofb[3]) {
      lst[icod].begin()->add4wsum(0, codon_get_CAI_value (aa, icd[0]) ) ; 
      lst[icod].begin()->add4wsum(1, codon_get_CPS_value ( bb, icd[1], aa, icd[0]) ) ; 
      lst[icod].begin()->add4wsum(2, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0])) ;
   }

   if (ofb[0]) { lst[icod].begin()->setCaiVal( 0, pow(exp( lst[icod].begin()->getSc(0)   ),1.0/((double)(aapos + 1)) ) ) ; }

}

void chain::setCodB (int icod, chain *cha, vector<bool> maximize) {
// Set lst[icod]. Check m (=mcods=mcodons) previous aa positions.
// icod is the serial index to specify the values of c_{i-k-1}...c_i in Equation 5.
// icd: c_{i-k-1}...c_i in Equation 5. c_i is icd[0].
// jcd: c_{i-k}...c_{i-1} in Equation 5. c_{i-1} is jcd[0].
   vector<int> icd, jcd ;
   list<score>::iterator it ;
   char bb = cha[aapos - 1].aa ;

   get_icd (icod, icd, cha) ;
   if ( forbiddenPatIncluded (icd, cha) ) return ; 

   int i ;
   for (i = 1 ; i <= mcods ; i++) jcd.push_back(icd[i]) ;
   jcd.push_back(0) ; // For jcd[m]. a dummy for allocating jcd[m]. Later overwrited.

   // Find a non-empty list (specified by jcd[]) at the previous aa position
   int jcodA ;
   for (jcodA = 0 ; jcodA < cha[aapos - mcods - 1].nCodType ; jcodA++) {
      jcd[mcods] = jcodA ;
      if (!cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].empty() ) break ;
   }
   if (jcodA == cha[aapos - mcods - 1].nCodType) return ; 

   lst[icod] = cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ] ; // Copy the first non-empty lst.
   list<score>::iterator jt = cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].begin() ;

   // This gives the first set of non-dominated solutions in the vmax operation of Equation 5 in the paper. 
   for (it = lst[icod].begin() ; it != lst[icod].end() ; it++) {
      int i = 0 ;

      // Add the score vector function values of the current aa posotion to update the elements (score vectors) of lst[icod].
      if (ofb[0]) it->add( i++, codon_get_CAI_value (aa, icd[0]) ) ;
      if (ofb[1]) it->add( i++, codon_get_CPS_value ( bb, icd[1], aa, icd[0]) ) ;
      if (ofb[2]) it->add( i++, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
      if (ofb[3]) it->add( i, weight[0]*codon_get_CAI_value (aa, icd[0])
                            + weight[1]*codon_get_CPS_value (bb, icd[1], aa, icd[0])
                            + weight[2]*codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
      it->set_bt (jcd[0]) ;
      it->set_it (jt) ; jt++ ;

      if (ofb[3]) {
         it->add4wsum(0, codon_get_CAI_value (aa, icd[0]) ) ; 
         it->add4wsum(1, codon_get_CPS_value (bb, icd[1], aa, icd[0]) ) ;
         it->add4wsum(2, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
      }

      if (ofb[0]) { it->setCaiVal( 0, pow(exp( it->getSc(0) ), 1.0/((double)(aapos + 1)) ) ) ; }

   }
   // Repeatedly merge the remaining non-dominanted solutions (ie the vmax operation of Equation 5 in the paper). 
   int jcod ;
   for (jcod = jcodA + 1 ; jcod < cha[aapos - mcods - 1].nCodType ; jcod++) { 
      jcd[mcods] = jcod ;

      // Check whether a non-empty list or not
      if ( cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].empty() ) continue ;

      list<score> lstNext ;
      lstNext = cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ] ; 

      list<score>::iterator jt = cha[aapos - 1].lst[ cha[aapos - 1].get_cod (jcd, cha) ].begin() ;
      for (it = lstNext.begin() ; it != lstNext.end() ; it++) {
         int i = 0 ;

         if (ofb[0]) it->add( i++, codon_get_CAI_value (aa, icd[0]) ) ;

         if (ofb[1]) it->add( i++, codon_get_CPS_value (bb, icd[1], aa, icd[0]) ) ;
         if (ofb[2]) it->add( i++, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
         if (ofb[3]) it->add( i, weight[0]*codon_get_CAI_value (aa, icd[0])
                               + weight[1]*codon_get_CPS_value (bb, icd[1], aa, icd[0])
                               + weight[2]*codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ; 
         it->set_bt (jcd[0]) ;
         it->set_it (jt) ; jt++ ;

         if (ofb[3]) {
            it->add4wsum(0, codon_get_CAI_value (aa, icd[0]) ) ; 
            it->add4wsum(1, codon_get_CPS_value (bb, icd[1], aa, icd[0]) ) ;
            it->add4wsum(2, codon_get_numStopCodon_value (bb, icd[1], aa, icd[0]) ) ;
         }

         if (ofb[0]) { it->setCaiVal( 0, pow(exp( it->getSc(0) ), 1.0/((double)(aapos + 1)) ) ) ; }

      }
      if (simpleMaxima) {
         simpleComparison4Merge (lst[icod], lstNext, nsc) ;
         simpleComparison4Merge (lstNext, lst[icod], nsc) ;
      }

      list<score> lstTmp ;
      sorted_splice (lstTmp, lst[icod], lstNext) ; 
      lst[icod].splice (lst[icod].end(), lstTmp) ;

      // call helperA

      if (!simpleMaxima) {
         if (nsc == 1) { singleOF (lst[icod]) ; }
         else if (nsc == 2) { twoOFs (lst[icod]) ; }
         else  { cout << "ERROR: #OFs >= 3 is not implemented.\n" ; exit(1) ; } ; 

      }

   }

   // Erase duplicate solutions if the OF values are the same with those of the previous list element.
   list<score>::iterator preit = lst[icod].begin() ;
   int nsame = 0 ;
   int np = 0, nOriginalListSize = lst[icod].size() ; 
   for (it = lst[icod].begin() ; it != lst[icod].end() ; ) {
      bool same = false ;
      if (dupliCheck) {
         if (it != lst[icod].begin()) {
            same = true ;
            int i = 0 ;

            if (ofb[0]) { if (it->getCaiVal() != preit->getCaiVal()) same = false ; i++ ; }
            if (ofb[1]) { if (it->getSc(i) != preit->getSc(i)) same = false ; i++ ; }
            if (ofb[2]) { if (it->getSc(i) != preit->getSc(i)) same = false ; i++ ; }
            if (ofb[3]) { if (it->getSc(i) != preit->getSc(i)) same = false ; }
            if (same) nsame++ ;
         }
      }

      bool flagErase = false ;

      if (!same) { 
         double delta = 1.0e-7 ;
         int i = 0 ;
         if (constraintb[0] && ofb[0]) {
            if (maximize[0]) {
               if (it->getSc(i++) + codon_get_CAI4constraint (aapos+1) + delta < aalen*log(constraint[0])) flagErase = true ; 
            } else {
               if (it->getSc(i++) + codon_get_CAI4constraintMin (aapos+1) > delta + aalen*log(constraint[0])) flagErase = true ; 
            } }

         if (constraintb[1] && ofb[1]) {
            if (maximize[1]) {
               if ((it->getSc(i++) + codon_get_CPB4constraint (aapos+1))/(aalen-1) + delta < constraint[1]) flagErase = true ;
            } else {
               if ((it->getSc(i++) + codon_get_CPB4constraintMin (aapos+1))/(aalen-1) > delta + constraint[1]) flagErase = true ;
            } }

         if (constraintb[2] && ofb[2]) {
            if (maximize[2]) {
               if ((it->getSc(i++) + codon_get_HSC4constraint (aapos+1)) + delta < constraint[2]) flagErase = true ;
            } else {
               if ((it->getSc(i++) + codon_get_HSC4constraintMin (aapos+1)) > delta + constraint[2]) flagErase = true ;
            } }
      }

      if (flagErase) np++ ;

      if (same || flagErase) { it = lst[icod].erase (it) ; } 
      else { preit = it ; it++ ; } 
   }

   if (verboseOut) cout << "n= " << nOriginalListSize << " np= " << np << " nsame= " << nsame <<  endl ; 

}

int chain::get_icd_zero (int icode, chain *cha) { // icode: gamma
// Input: a serial codon index of multiple aa positions.
// Output: a codon index at aapos.
   int i, x = 1 ;
   for (i = 1 ; i <= mcods ; i++) x *= cha[aapos - i].nCodType ;
   return icode/x ; 
}

void chain::get_icd (int icode, vector<int> &icd, chain *cha) { // icode: gamma

// Input: a serial codon index, icode, of multiple aa positions.
// Output: codon index array, icd.
// Correspondance between icd[] and aa positions, and Equation 5 in the paper.
//    icd[m]   ...  icd[1]   icd[0]
//    aapos-m  ...  aapos-1  aapos
//    c_{i-k-1} ...  c_{i-1}    c_i 
   int i, x = 1, y ;
   for (i = 1 ; i <= mcods ; i++) x *= cha[aapos - i].nCodType ; // Excluding an aapos (i = 0)
   for (i = 0 ; i < mcods ; i++) { 
      y = icode/x ; 
      icd.push_back (y) ;
      icode -= y*x ;
      x /= cha[aapos - i - 1].nCodType ;
   }
   icd.push_back (icode) ; // For i == m
}

int chain::get_cod (vector<int> &jcd, chain *cha) { // cod: gamma
// Input: codon index array, icd.
// Output: a serial codon index, icode, of multiple aa positions.
   int jcod = 0 ;
   int i, m = 1 ;
   for (i = jcd.size() - 1 ; i >= 0 ; i--) { // jcd.size() - 1 = mcods
      jcod += jcd[i]*m ;
      m *= cha[aapos - i].nCodType ;
   }
   return jcod ; // jcod: gamma
}

void dp::dpmain (char *aaseq, string pat, vector<string> of, vector<bool> maximize, vector<double> constraint, vector<double> weight, bool dupliCheck, vector<bool> constraintb, bool simpleMaxima, bool verboseOut) {
   aastr = string( (const char*)aaseq ) ;
   aalen = aastr.length() ;

   int mcodons = 1 ; // A default setting. K_score = 2 is assumed. If we use only CAI (K_score = 2), mcodons can be set to 0 (not implemented).

   if (pat.size() != 0) {
      list<string> patterns ;
      int plen ; 
      boost::split (patterns, pat, boost::is_any_of("|")) ;
      BOOST_FOREACH (string s, patterns) {
         if (s.size()%3==1) { plen = (int)(s.size()/3) + 1 ; } // +1 for ceil
         else if (s.size()%3==0) { plen = (int)(s.size()/3) + 1 ; } // +1 for Eq. 4
         else { plen = (int)(s.size()/3) + 2 ; } 
         if (mcodons < plen - 1) mcodons = plen - 1 ; // -1 because "mcodons" >= 0.
         if (s.size() < 3) { cout << "ERROR: a max. pattern is too short." << endl ; exit(0) ; }  
      }
      if (mcodons + 1 > aalen) { // +1 because "mcodons" >= 0.
          cout << "ERROR: a max. pattern is too long." << endl ; 
          exit(0) ;
      }
   }

   cout << "forbiddenPattern= " << pat << endl ;
   cout << "mcodons= " << mcodons << endl ;

   cha = new chain [aalen + 1] ; // + 1 for the final Pareto solutions.

   // Set paramtets for cha[]
   for (int i =  0 ; i <= aalen ; i++) cha[i].set (aalen, of, constraint, weight, dupliCheck, constraintb, simpleMaxima, verboseOut) ;

   cha[0].set (0, aastr.c_str()[0], mcodons, cha, pat, maximize) ;
   for (int i =  1 ; i < aalen ; i++) 
      cha[i].set (i, aastr.c_str()[i], mcodons, cha, pat, maximize) ;
   cha[aalen].set (aalen, cha) ;
   // Traceback
   list<score>::iterator it, jt ;
   int ipareto = 1 ;
   for (it = cha[aalen].get_begin(0) ; it != cha[aalen].get_end(0) ; it++) {
      vector<int> seq ;
      jt = it ;
      for (int i = aalen ; i >= 1 ; i--) { 
         seq.push_back( jt->get_bt() ) ;
         jt = jt->get_it() ;
      }
      reverse(seq.begin(), seq.end()) ;

      // Output scores and the sequence of codons
      if (ipareto != 1) cout << endl ;
      cout << "Solution= " << ipareto++ << " Sc= " ; 
      for (int i = 0 ; i < of.size() ; i++) {
         if (of[i] == "CAI") cout << " " << pow(exp(it->getSc(i)),1.0/((double)aalen)) ;
         else if (of[i] == "CPB") cout << " " << it->getSc(i)/((double)aalen-1.0) ;
         else { cout << " " << it->getSc(i) ; }

      }

      if (verboseOut) {
         // for score check
         int *cksq ;
         cksq = (int *)calloc(sizeof(int), aalen) ;
         for (int i = 0 ; i < aalen ; i++) cksq[i] = seq[i] ;

         cout << "  F=" ; 
         for (int i = 0 ; i < of.size() ; i++) {
            if (of[i] == "CAI") printf(" %f", codon_score_cai(cksq) ) ;
            else if (of[i] == "CPB") printf(" %f", codon_score_cpb(cksq) ) ;
            else { printf(" %f", codon_score_hsc(cksq) ) ; }
         }

         cout << "  Ck=" ; 
         for (int i = 0 ; i < of.size() ; i++) {
            if (of[i] == "CAI") cout << " " << fabs(codon_score_cai(cksq) - pow(exp(it->getSc(i)),1.0/((double)aalen))) ;
            else if (of[i] == "CPB") cout << " " << fabs(codon_score_cpb(cksq) - it->getSc(i)/((double)aalen-1.0)) ;
            else { cout << " " << fabs(codon_score_hsc(cksq) - it->getSc(i)) ; }
         }

         free (cksq) ;
      }

      cout << endl ;
      for (int i = 0 ; i < aalen ; i++) 
         cout << codon_get_triplet (aastr.c_str()[i], seq[i] ) ;
      cout << endl ;

      for (int i = 0 ; i < of.size() ; i++) {
         if (of[i] == "wsum") {
            cout << "weight: " ;
            for (int j = 0 ; j < 3 ; j++) cout << weight[j]  << " " ;
            cout << endl ;
            cout << "wsumScoreVec: " ; // The values output here are used as the values in a pruningList.

            cout << it->getSc4wsum(0) << " " << it->getSc4wsum(1) << " " << it->getSc4wsum(2) << endl ; 
         }
      }

      if (verboseOut) {
      for (int i = 0 ; i < of.size() ; i++) {
         if (of[i] == "CAI") {
            cout << "CAI(relative adaptiveness) " ;
            for (int j = 0 ; j < aalen ; j++) 
               cout << exp( codon_get_CAI_value (aastr.c_str()[j], seq[j]) ) << " " ;
            cout << endl ;
         } else if (of[i] == "CPB") {
            cout << "CPB " ;                    
            for (int j = 0 ; j < aalen - 1 ; j++) 
               cout << codon_get_CPS_value (aastr.c_str()[j], seq[j], aastr.c_str()[j+1], seq[j+1]  ) << " " ;
            cout << endl ;
         } else if (of[i] == "HSC") {
            cout << "HSC " ;                    
            for (int j = 0 ; j < aalen - 1 ; j++) 
               cout << codon_get_numStopCodon_value (aastr.c_str()[j], seq[j], aastr.c_str()[j+1], seq[j+1]  ) << " " ;
            cout << endl ;
         }
      }
      }
   }
}

int main (int argc, char *argv[]) {
   int ntot ; 
   string version = "0.9.0" ;

   if (argc == 1) {
      printf("To see help, please type \"cosmo -h\" or \"--help\" or \"-help\".\n") ;
      exit(0) ;
   }

   if (setpar_chk(argc, argv, "-h") || setpar_chk(argc, argv, "--help") ||
       setpar_chk(argc, argv, "-help")) {
      cout << endl ;
      cout << "COSMO : Codon Optimization Strategy with Multiple Objectives [version " << version << "]" << endl ;
      cout << endl ;
      cout << " Usage: cosmo [options] -aa -f amino_acid_sequence_filename" << endl ;
      cout << "        or" << endl ;
      cout << "        cosmo [options] -f CDS_filename" << endl ;
      cout << endl ;
      cout << " -t [codon frequency file]" << endl ;
      cout << " -u [codon pair frequency file]" << endl ;
      cout << " -p [forbidden nucleotide pattern] : eg -p \"AAAAA|CCCCC\"" << endl ;
      cout << " -of [CAI/CPB/HSC/wsum] : eg -of CAI maximizes CAI score." << endl ;
      cout << " -max [CAI/CPB/HSC/wsum] : eg -max CAI maximizes CAI score." << endl ;
      cout << " -min [CAI/CPB/HSC/wsum] : eg -min CAI minimizes CAI score." << endl ;
      cout << " -cai-c [constraint value] : eg -cai-c 0.8" << endl ;
      cout << " -cpb-c [constraint value] : eg -cpb-c 0.0" << endl ;
      cout << " -hsc-c [constraint value] : eg -hsc-c 10" << endl ;
      cout << endl ;
      cout << " Weights for the weighted sum of OFs; note: a negative value indicates minimization:" << endl ;
      cout << "   -cai-w [a weight for wsum] : eg -cai-w 1.0" << endl ;
      cout << "   -cpb-w [a weight for wsum] : eg -cpb-w 1.0" << endl ;
      cout << "   -hsc-w [a weight for wsum] : eg -hsc-w 1.0" << endl ;
      cout << endl ;
      cout << " -w4pruning : automatically set the weights for pruning." << endl ;

      cout << " -pruningList : a score vector list for pruning is read from stdin." << endl ;
      cout << " -d or -dupliCheck : duplicate score vectors are deleted during the recurrence computation." << endl ;

      cout << " -minrate [rate] : specify a minimum rate for f(c_i)/f(lambda(c_i)). If a zero or a very small value (causes overflow in log) is found in codon frequencies and/or codon pair frequencies, this option should be used. This option adds [rate] to each of all codons of an amino acid, then normalizes them." << endl ;
      cout << " -outrates : output codon rates and/or codon pair rates." << endl ;

      cout << endl ;
      cout << " Automatic determination of constraints." << endl ;
      cout << " If -\?\?\?-constFact is specified, max and min values for the OF are used to automatically determining the constraints. " ;
      cout << " Eg if -cai-constFact 0.8 is specified for maximization, ([max CAI] - [min CAI])*0.8+[min CAI] is used as the constraint. " ;
      cout << " In addition, if -iconstFact is also specified, an OF value of the solution in the pruning list is used as the [max] or [min] value in the automatic determination of the constraint (according to maximization or minimization)." << endl ;
      cout << " -cai-constFact [factor]" << endl ;
      cout << " -cpb-constFact [factor]" << endl ;
      cout << " -hsc-constFact [factor]" << endl ;
      cout << " -iconstFact [solution in the pruning list] : eg -constFact 1 indicates the 1st solution in the list." << endl ;
      cout << endl ;
      cout << " -simpleMaxima : for debugging." << endl ;
      cout << " -verboseOut : output #solutions deleted by the pruning. For debugging." << endl ;
      exit(0) ;
   }

   FILE *fp = fopen(setpar_s(argc, argv, "-f", stdout),"r") ; 
   if (fp == NULL) { cout << "ERROR: -f file not found" << endl ;  exit(1) ; }

   cout << "COSMO [version " << version << "]" << endl ;
   codon_init (argc, argv, fp, &ntot) ;
   fclose (fp) ;

   string pat = "" ;

   if (setpar_chk (argc, argv, "-p")) { 
      string t = setpar_s (argc, argv, "-p", stdout) ; 
      if (pat == "") pat = t ;
      else pat += "|" + t ;
   }
   // [ACGUT|] is allowed.
   sregex rex = sregex::compile("[^ACGUT.|]") ;
   smatch match ;
   if ( regex_search (pat, match, rex ) ) {
      cout << "ERROR: -p [^ACGUT.|] is not allowed." << endl ; exit(0) ;
   }

   vector<string> of ;
   vector<bool> maximize (4, true), ofb(4, false) ;
   vector<double> constraint ;
   for (int i = 1 ; i < argc - 1 ; i++) {  
      if (strcmp(argv[i], "-of") == 0 || strcmp(argv[i], "-max") == 0 || strcmp(argv[i], "-min") == 0) {
         rex = sregex::compile("[^ACGUT.]") ;
         smatch match ;
         string s = argv[i + 1] ;

         if (s == "CAI") { ofb[0] = true ; if (strcmp(argv[i], "-min") == 0) maximize[0] = false ; }
         else if (s == "CPB") { ofb[1] = true ; if (strcmp(argv[i], "-min") == 0) maximize[1] = false ; }
         else if (s == "HSC") { ofb[2] = true ; if (strcmp(argv[i], "-min") == 0) maximize[2] = false ; }
         else if (s == "wsum") { ofb[3] = true ; if (strcmp(argv[i], "-min") == 0) maximize[3] = false ; }
         else {
            cout << "ERROR: -of " << s << endl ; exit(0) ;
         }
      }
   }  

   if (ofb[0]) of.push_back("CAI") ;
   if (ofb[1]) of.push_back("CPB") ;
   if (ofb[2]) of.push_back("HSC") ;
   if (ofb[3]) of.push_back("wsum") ;

   if (of.size() == 0) { // Default OFs. These three are maximized.
      of.push_back("CAI") ;
      of.push_back("CPB") ;

   }

   vector<double> weight ; 
   weight.push_back(setpar_f (argc, argv, "-cai-w", 1.0, -1.0, 1.0, stdout)) ; // CAI max
   weight.push_back(setpar_f (argc, argv, "-cpb-w", 1.0, -1.0, 1.0, stdout)) ; // CPB max
   weight.push_back(setpar_f (argc, argv, "-hsc-w", 1.0, -1.0, 1.0, stdout)) ; // HSC max

   if (setpar_chk (argc, argv, "-w4pruning")) { 
      // For minimization, set -1.0 by -cai-w, -cpb-w, or -stop-w
      weight[0] *= 1.0/(codon_get_CAI4constraint(0) - codon_get_CAI4constraintMin(0)) ;
      weight[1] *= 1.0/(codon_get_CPB4constraint(1) - codon_get_CPB4constraintMin(1)) ;
      weight[2] *= 1.0/(codon_get_HSC4constraint(1) - codon_get_HSC4constraintMin(1)) ;

      cout << "CAI max= " << codon_get_CAI4constraint(0) << " min= "<< codon_get_CAI4constraintMin(0) << endl ;
      cout << "CPB max= " << codon_get_CPB4constraint(1) << " min= "<< codon_get_CPB4constraintMin(1) << endl ;
      cout << "HSC max= " << codon_get_HSC4constraint(1) << " min= "<< codon_get_HSC4constraintMin(1) << endl ;
   }

   cout << "Maximization: " << "CAI:" << maximize[0] << " CPB:" << maximize[1] << " HSC:" << maximize[2]  << " wsum:" << maximize[3] << endl ;

   vector<vector<double> > constrVec ;
   if (setpar_chk (argc, argv, "-pruningList")) { 
      double cai, cpb, stop ;

      while ( cin >> cai >> cpb >> stop ) {
         vector<double> cV ;
         cV.push_back(cai) ;  
         cV.push_back(cpb) ;  
         cV.push_back(stop) ; 
         constrVec.push_back (cV) ;
      }
   }

   for (int i = 0 ; i < constrVec.size() ; i++) {
      cout << "prlist " << constrVec[i][0] << " " << constrVec[i][1] << " " << constrVec[i][2] << endl ;
   }

   bool dupliCheck = false ;
   if (setpar_chk (argc, argv, "-dupliCheck")) dupliCheck = true ;
   else if (setpar_chk (argc, argv, "-d")) dupliCheck = true ;

   vector <bool> constraintb ;
   constraint.push_back(0) ; constraintb.push_back(false) ; // CAI
   constraint.push_back(0) ; constraintb.push_back(false) ; // CPB
   constraint.push_back(0) ; constraintb.push_back(false) ; // HSC
   constraint.push_back(0) ; constraintb.push_back(false) ; // wsum

   if (setpar_chk (argc, argv, "-cai-c"))  {
      constraintb[0] = true ;
      constraint[0] = setpar_f (argc, argv, "-cai-c", 0.8, 0.0, 1.0, stdout) ; // For CAI max
   }
   if (setpar_chk (argc, argv, "-cpb-c")) {
      constraintb[1] = true ;
      constraint[1] = setpar_f (argc, argv, "-cpb-c", 0.0, -999999.0, 999999.0, stdout) ; // For CPB max
   }
   if (setpar_chk (argc, argv, "-hsc-c")) {
      constraintb[2] = true ;
      constraint[2] = setpar_f (argc, argv, "-hsc-c",  0.0, 0.0, 999999.0, stdout) ; // For HSC max
   }
   if (setpar_chk (argc, argv, "-wsum-c")) { 
      constraintb[3] = true ;
      constraint[3] = setpar_f (argc, argv, "-wsum-c", 0.0, 0.0, 999999.0, stdout) ;
   }

   // Set constraint values based on the max. or min. socre values or the values in the pruningList.
   // When iconstFact != 0, pruningList is used.

   int iconstFact = setpar_i (argc, argv, "-iconstFact", 0, 0, 999999, stdout) ;

   if (setpar_chk (argc, argv, "-cai-constFact")) {

      constraintb[0] = true ;
      double constFact = setpar_f (argc, argv, "-cai-constFact", 0.8, 0.0, 1.0, stdout) ; 
      // For iconstFact == 0
      double max = pow(exp(codon_get_CAI4constraint(0)),1.0/((double)ntot)) ;
      double min = pow(exp(codon_get_CAI4constraintMin(0)),1.0/((double)ntot)) ;
      if (iconstFact > 0) { // For iconstFact != 0
         if (maximize[0]) max = pow(exp(constrVec[iconstFact - 1][0]),1.0/((double)ntot)) ;
         else             min = pow(exp(constrVec[iconstFact - 1][0]),1.0/((double)ntot)) ;
      }
      if (maximize[0]) constraint[0] = min + constFact*(max-min) ;
      else             constraint[0] = max - constFact*(max-min) ;
      cout << "constraints_by_-cai-constFact:" << " -cai-c " << constraint[0] << endl ;
   }
   if (setpar_chk (argc, argv, "-cpb-constFact")) {

      constraintb[1] = true ;
      double constFact = setpar_f (argc, argv, "-cpb-constFact", 0.8, 0.0, 1.0, stdout) ; 
      // For iconstFact == 0
      double max = codon_get_CPB4constraint(1)/((double)ntot-1.0) ;
      double min = codon_get_CPB4constraintMin(1)/((double)ntot-1.0) ;
      if (iconstFact > 0) {  // For iconstFact != 0
         if (maximize[1]) max = constrVec[iconstFact - 1][1]/((double)ntot-1.0) ;
         else             min = constrVec[iconstFact - 1][1]/((double)ntot-1.0) ;
      }
      if (maximize[1]) constraint[1] = min + constFact*(max-min) ;
      else             constraint[1] = max - constFact*(max-min) ;
      cout << "constraints_by_-cpb-constFact:" << " -cpb-c " << constraint[1] << endl ;
   }
   if (setpar_chk (argc, argv, "-hsc-constFact")) {

      constraintb[2] = true ;
      double constFact = setpar_f (argc, argv, "-hsc-constFact", 0.8, 0.0, 1.0, stdout) ; 
      // For iconstFact == 0
      double max = codon_get_HSC4constraint(1)  ; 
      double min = codon_get_HSC4constraintMin(1)  ;
      if (iconstFact > 0) { // For iconstFact != 0 
         if (maximize[2]) max = constrVec[iconstFact - 1][2] ; 
         else             min = constrVec[iconstFact - 1][2] ; 
      }
      if (maximize[2]) constraint[2] = min + constFact*(max-min) ;
      else             constraint[2] = max - constFact*(max-min) ;
      cout << "constraints_by_-hsc-constFact:" << " -hsc-c " << constraint[2] << endl ;
   }
   cout << "constraintb (CAI): " << constraintb[0] << endl ;
   cout << "constraintb (CPB: " << constraintb[1] << endl ;
   cout << "constraintb (HSC): " << constraintb[2] << endl ;
   cout << "constraintb (wsum): " << constraintb[3] << endl ;

   bool simpleMaxima = false ;
   if (setpar_chk (argc, argv, "-simpleMaxima")) simpleMaxima = true ;
   bool verboseOut = false ;
   if (setpar_chk (argc, argv, "-verboseOut")) verboseOut = true ;

   int nof = of.size() ;

   printf("#MAX&MIN nof= %d ", nof );
   for (int i = 0 ; i < nof ; i++) {
      if (of[i] == "CAI") { printf(" CAI"); if (maximize[0]) printf ("(max)") ; else printf("(min)") ;
      } else if (of[i] == "CPB") { printf(" CPB") ; if (maximize[1]) printf ("(max)") ; else printf("(min)") ;
      } else if (of[i] == "HSC") { printf(" HSC") ; if (maximize[2]) printf ("(max)") ; else printf("(min)") ;
      } else if (of[i] == "wsum") { printf(" wsum") ; if (maximize[3]) printf ("(max)") ; else printf("(min)") ;
      } else { printf("\nERROR\n"); exit(1) ;
      }
   }
   printf("\n");

   for (int i = 0 ; i < nof ; i++) {
      if (of[i] == "CAI") {
         double max = pow(exp(codon_get_CAI4constraint(0)),1.0/((double)ntot)) ;
         double min = pow(exp(codon_get_CAI4constraintMin(0)),1.0/((double)ntot)) ;

         printf("%lf %lf\n", max, min);
      } else if (of[i] == "CPB") {
         double max = codon_get_CPB4constraint(1)/((double)ntot-1.0) ;
         double min = codon_get_CPB4constraintMin(1)/((double)ntot-1.0) ;

         printf("%lf %lf\n", max, min) ;
      } else if (of[i] == "HSC") {
         double max = codon_get_HSC4constraint(1)  ; 
         double min = codon_get_HSC4constraintMin(1)  ;

         printf("%lf %lf\n", max, min);
      } else {

         printf("notComputed notComputed\n");
      }
   }

   dp DP ;
   try {
      DP.dpmain (codon_get_aachar(), pat, of, maximize, constraint, weight, dupliCheck, constraintb, simpleMaxima, verboseOut) ;
   }
   catch (bad_alloc &e) { cout << "ERROR: Memory allocation failed\n" ; exit(1) ; }
   codon_post () ;
   return 0 ;
}
