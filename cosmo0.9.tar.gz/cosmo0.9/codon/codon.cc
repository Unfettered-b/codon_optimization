#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <string>
#include <fstream>

#include "codon.h"
#include "../setpar/setpar.h"

#define CODON_INDEX_MAX 6
#define AA_NUM 21

static double targetFreq[AA_NUM][CODON_INDEX_MAX] ;
static double targetPairFreq[AA_NUM - 1][CODON_INDEX_MAX][AA_NUM][CODON_INDEX_MAX] ;
static double relative_adapt[AA_NUM][CODON_INDEX_MAX] ; //for CAI
static double numStopCodon[AA_NUM - 1][CODON_INDEX_MAX][AA_NUM][CODON_INDEX_MAX] ;
static char *aachar, *ntchar ;

static int *aaseq ;
static int aalen, *codonmax, ntlen ;
static char codon_table[AA_NUM][CODON_INDEX_MAX][4] ; // e.g. "TGA\0"

static double *cai4constraint, *cai4constraintMin ;
static double *cpb4constraint, *cpb4constraintMin ;
static double *hsc4constraint, *hsc4constraintMin ;
static double minrate, outrates = 0 ;

void codon_init (int argc, char *argv[], FILE *fp, int *lenCodonSeq) { // fp is no longer used.

   int i, j, k, l ;

   ntlen = 0 ;
   aalen = 0 ;

   minrate = setpar_f (argc, argv, "-minrate", 0.0001, 0.0, 1.0/CODON_INDEX_MAX, stdout) ;
   if ( setpar_chk(argc, argv, "-outrates")) outrates = 1 ;

   std::ifstream ifs (setpar_s(argc, argv, "-f", stdout)) ; 
   if (!ifs.is_open()) {

      printf ("ERROR: a file for -f was not opened.\n");
      exit(1);
   }

   std::string seq ;
   if ( setpar_chk(argc, argv, "-aa")) { // an aa sequence input
      getline(ifs, seq) ; aalen = seq.size() ;

      ntlen = aalen*3 ;
   } else { // a nucleotide sequence input
      getline(ifs, seq) ; ntlen = seq.size() ;

      if (ntlen % 3 != 0) { printf ("ERROR: ntlen %% 3 != 0.\n") ; exit (1) ; }
      aalen = ntlen/3 ;
   }
   *lenCodonSeq = aalen ;

   for (i = 0 ; i < AA_NUM ; i++) {
      for (j = 0 ; j < CODON_INDEX_MAX ; j++) {
         targetFreq[i][j]= 0.0 ;

      }
   }

   for (i = 0 ; i < AA_NUM - 1; i++) {
      for (j = 0 ; j < CODON_INDEX_MAX ; j++) { 
         for (k = 0 ; k < AA_NUM ; k++) {
            for (l = 0 ; l < CODON_INDEX_MAX ; l++) { 
       	       targetPairFreq[i][j][k][l] = -999.9 ;
       	       numStopCodon[i][j][k][l]     = 0.0 ;
            }
         }
      }
   }

   for (i = 0 ; i < AA_NUM ; i++) {
      for (j = 0 ; j < CODON_INDEX_MAX ; j++) { 
         strcpy (codon_table[i][j], "NNN");
      }
   }

   aachar = (char *) calloc(aalen + 1, sizeof(char)) ;
   ntchar = (char *) calloc(ntlen + 1,sizeof(char)) ;
   aaseq = (int *) calloc(aalen, sizeof(int)) ;
   codonmax = (int *) calloc (AA_NUM, sizeof(int)) ;

   if (aachar==NULL || ntchar==NULL || aaseq==NULL || codonmax==NULL) { printf ("ERROR: memory allocation error in codon.c.") ; exit(1) ; } 

   codon_read_targetFreq (argc, argv) ; // codonmax and codon_table are defined here.
   if ( setpar_chk(argc, argv, "-u") ) codon_read_targetPairFreq (argc, argv) ;
   else if ( setpar_chk(argc, argv, "-of-cc") ) codon_read_targetPairFreq (argc, argv) ;
   else if ( setpar_chk(argc, argv, "-of-ccai") ) codon_read_targetPairFreq (argc, argv) ;

   // set relative_adapt[][] for CAI
   // note: codon_read_targetFreq () should be called before the following.
   for (i = 0 ; i < AA_NUM ; i++) {
      int jmax = 0 ;
      for (j = 1 ; j < codonmax[i] ; j++) 
         if (targetFreq[i][jmax] < targetFreq[i][j]) jmax = j ;
      for (j = 0 ; j < codonmax[i] ; j++) 
         relative_adapt[i][j] = targetFreq[i][j]/targetFreq[i][jmax] ;

   }

   // for HSC
   for (i = 0 ; i < AA_NUM - 1 ; i++) {
      for (j = 0 ; j < AA_NUM ; j++) {
         for (k = 0 ; k < codonmax[i] ; k++) {
            for (l = 0 ; l < codonmax[j] ; l++) {
               int cn = 0 ;
               char c[4] ; c[3] = '\0' ;
               c[0] = codon_table [i][k][1] ;
               c[1] = codon_table [i][k][2] ;
               c[2] = codon_table [j][l][0] ;
               int m ;
               for (m = 0 ; m < codonmax[20] ; m++) 
                  if (strcmp (c, codon_table [20][m]) == 0) { cn++ ; break ; } // stop codons
               c[0] = codon_table [i][k][2] ;
               c[1] = codon_table [j][l][0] ;
               c[2] = codon_table [j][l][1] ;
               for (m = 0 ; m < codonmax[20] ; m++) 
                  if (strcmp (c, codon_table [20][m]) == 0) { cn++ ; break ; } // stop codons
               numStopCodon[i][k][j][l] = (double)cn ;
            }
         }
      }
   }

   if ( setpar_chk(argc, argv, "-aa") ) { // an aa sequence input
      strcpy (aachar, const_cast<char *>(seq.c_str())) ;
      for (i = 0 ; i < aalen ; i++) {
         aaseq[i] = codon_aa2aa_index (aachar[i]) ;
         ntchar[3*i] = codon_table[ aaseq[i] ][0][0] ; // assign the first codon of the aa.
         ntchar[3*i+1] = codon_table[ aaseq[i] ][0][1] ;
         ntchar[3*i+2] = codon_table[ aaseq[i] ][0][2] ;
      }

   } else { // a nucleotide sequence input
      strcpy (ntchar, const_cast<char *>(seq.c_str())) ;
      for (i = 0 ; i < aalen ; i++) {
         aachar[i] = codon_codon_nt2aachar ( &(ntchar[i*3]) ) ;
         aaseq[i] = codon_aa2aa_index (aachar[i]) ;
      }

   }

   printf ("AminoAcidSequence: %s\n", aachar) ;

   int * sq = (int *) calloc(aalen, sizeof(int)) ;
   for (i = 0 ; i < aalen ; i++) sq[i] = codon_nt2codonIndex ( &(ntchar[i*3]) ) ;
   if ( setpar_chk(argc, argv, "-aa") ) 
      printf ("NucleotideSequence (arbitrarily generated): %s\n", ntchar) ;
   else
      printf ("NucleotideSequence : %s\n", ntchar) ;

   printf ("CAI: %f\n", codon_score_cai (sq) ) ;
   for (i = 0 ; i < aalen ; i++) {

      printf ("%f ", exp( codon_get_CAI_value (aachar[i], codon_nt2codonIndex (&(ntchar[i*3])) ))) ;
   }
   printf ("\n") ; 

   if ( targetPairFreq[0][0][0][0] != -999.9 ){
   printf ("CAB: %f\n", codon_score_cpb (sq) ) ;
   for (i = 0 ; i < aalen - 1 ; i++) {
      printf ("%f ", codon_get_CPS_value ( aachar[i], codon_nt2codonIndex (&(ntchar[i*3])), 
                                            aachar[i+1], codon_nt2codonIndex (&(ntchar[(i+1)*3])) )
             ) ;
   }
   printf ("\n") ; }

   printf ("HSC: %f\n", codon_score_hsc (sq) ) ;
   for (i = 0 ; i < aalen - 1 ; i++) {
      printf ("%f ", codon_get_numStopCodon_value ( aachar[i], codon_nt2codonIndex (&(ntchar[i*3])), 
                                            aachar[i+1], codon_nt2codonIndex (&(ntchar[(i+1)*3])) )
             ) ;
   }
   printf ("\n") ; 
   free (sq) ;

   // v_{CAI}^*(a_{i+1},...,a_L).    
   // compute the maximal score of each suffix of an input amino acid sequence. cai4constraint[x] is the maximal score of the suffix aachar[x] to aachar[L-1], where L is aalen.
   cai4constraint = (double *) calloc(aalen, sizeof(double)) ;
   if (cai4constraint==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   for (i = 0 ; i < aalen ; i++) cai4constraint[i] = 0.0 ;
   for (j = aalen-1 ; j >= 0 ; j--) {
      cai4constraint[j] = codon_get_CAI_value (aachar[j],0) ;
      for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
         if (cai4constraint[j] < codon_get_CAI_value (aachar[j],k)) 
            cai4constraint[j] = codon_get_CAI_value (aachar[j],k) ;
      if (j != aalen - 1) cai4constraint[j] += cai4constraint[j + 1] ;
   }
   // compute the minimal score of each suffix of an input amino acid sequence. for the constraints for minimization.

   cai4constraintMin = (double *) calloc(aalen, sizeof(double)) ;
   if (cai4constraintMin==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   for (i = 0 ; i < aalen ; i++) cai4constraintMin[i] = 0.0 ;
   for (j = aalen-1 ; j >= 0 ; j--) {
      cai4constraintMin[j] = codon_get_CAI_value (aachar[j],0) ;
      for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
         if (cai4constraintMin[j] > codon_get_CAI_value (aachar[j],k)) 
            cai4constraintMin[j] = codon_get_CAI_value (aachar[j],k) ; 
      if (j != aalen - 1) cai4constraintMin[j] += cai4constraintMin[j + 1] ;
   }

   // v_{CPB}^*(a_i,...,a_L).
   // compute the maximal score of each suffix of an input amino acid sequence. cpb4constraint[j] is the maximal score of a partial amino acid sequence from aachar[j] to aachar[L-1], where codon assignments of aa position j-1 are also taken into account (L is aalen). 

   cpb4constraint = (double *) calloc(aalen, sizeof(double)) ;
   if (cpb4constraint==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   double constA[CODON_INDEX_MAX] ;
   double constB[CODON_INDEX_MAX] ;
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constA[i] = 0.0 ;
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constB[i] = 0.0 ;
   for (i = 0 ; i < aalen ; i++) cpb4constraint[i] = 0.0 ;
   for (j = aalen-1 ; j > 0 ; j--) {
      for (i = 0 ; i < codonmax[ aaseq[j - 1] ] ; i++) { // (*)
         constB[i] = codon_get_CPS_value (aachar[j - 1],i,aachar[j],0) + constA[0] ;
         for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
            if (constB[i] < codon_get_CPS_value (aachar[j - 1],i,aachar[j],k) + constA[k] ) 
               constB[i] = codon_get_CPS_value (aachar[j - 1],i,aachar[j],k) + constA[k] ; 
      }
      cpb4constraint[j] = constB[0]; // (**)
      for (i = 1 ; i < codonmax[ aaseq[j-1] ] ; i++) if (cpb4constraint[j] < constB[i] ) cpb4constraint[j] = constB[i] ;
      for (i = 0 ; i < codonmax[ aaseq[j-1] ] ; i++) constA[i] = constB[i] ;
   }
   // compute the minimal score of each suffix of an input amino acid sequence. for the constraints for minimization.
   cpb4constraintMin = (double *) calloc(aalen, sizeof(double)) ;
   if (cpb4constraintMin==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constA[i] = 0.0 ;
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constB[i] = 0.0 ;
   for (i = 0 ; i < aalen ; i++) cpb4constraintMin[i] = 0.0 ;
   for (j = aalen-1 ; j > 0 ; j--) {
      for (i = 0 ; i < codonmax[ aaseq[j - 1] ] ; i++) {
         constB[i] = codon_get_CPS_value (aachar[j - 1],i,aachar[j],0) + constA[0] ;
         for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
            if (constB[i] > codon_get_CPS_value (aachar[j - 1],i,aachar[j],k) + constA[k] ) 
               constB[i] = codon_get_CPS_value (aachar[j - 1],i,aachar[j],k) + constA[k] ; 
      }
      cpb4constraintMin[j] = constB[0];
      for (i = 1 ; i < codonmax[ aaseq[j-1] ] ; i++) if (cpb4constraintMin[j] > constB[i] ) cpb4constraintMin[j] = constB[i] ;
      for (i = 0 ; i < codonmax[ aaseq[j-1] ] ; i++) constA[i] = constB[i] ;
   }
   // v_{HSC}^*(a_i,...,a_L).
   hsc4constraint = (double *) calloc(aalen, sizeof(double)) ;
   if (hsc4constraint==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constA[i] = 0.0 ;
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constB[i] = 0.0 ;
   for (i = 0 ; i < aalen ; i++) hsc4constraint[i] = 0.0 ;
   for (j = aalen-1 ; j > 0 ; j--) {
      for (i = 0 ; i < codonmax[ aaseq[j - 1] ] ; i++) {
         constB[i] = codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],0) + constA[0] ;
         for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
            if (constB[i] < codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],k) + constA[k] ) 
               constB[i] = codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],k) + constA[k] ; 
      }
      hsc4constraint[j] = constB[0];
      for (i = 1 ; i < codonmax[ aaseq[j-1] ] ; i++) if (hsc4constraint[j] < constB[i] ) hsc4constraint[j] = constB[i] ;
      for (i = 0 ; i < codonmax[ aaseq[j-1] ] ; i++) constA[i] = constB[i] ;
   }
   // compute the minimal score of each suffix of an input amino acid sequence. for the constraints for minimization.
   hsc4constraintMin = (double *) calloc(aalen, sizeof(double)) ;
   if (hsc4constraintMin==NULL) { printf ("ERROR: memory allocation error in constraint@codon.c.") ; exit(1) ; } 
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constA[i] = 0.0 ;
   for (i = 0 ; i < CODON_INDEX_MAX ; i++) constB[i] = 0.0 ;
   for (i = 0 ; i < aalen ; i++) hsc4constraintMin[i] = 0.0 ;
   for (j = aalen-1 ; j > 0 ; j--) {
      for (i = 0 ; i < codonmax[ aaseq[j - 1] ] ; i++) {
         constB[i] = codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],0) + constA[0] ;
         for (k = 1 ; k < codonmax[ aaseq[j] ] ; k++) 
            if (constB[i] > codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],k) + constA[k] ) 
               constB[i] = codon_get_numStopCodon_value (aachar[j - 1],i,aachar[j],k) + constA[k] ; 
      }
      hsc4constraintMin[j] = constB[0];
      for (i = 1 ; i < codonmax[ aaseq[j-1] ] ; i++) if (hsc4constraintMin[j] > constB[i] ) hsc4constraintMin[j] = constB[i] ;
      for (i = 0 ; i < codonmax[ aaseq[j-1] ] ; i++) constA[i] = constB[i] ;
   }

   return ; 
}

void codon_post () {
   free(hsc4constraintMin) ; 
   free(hsc4constraint) ; 
   free(cai4constraintMin) ; 
   free(cai4constraint) ; 
   free(cpb4constraintMin) ; 
   free(cpb4constraint) ; 
   free(aachar) ;
   free(ntchar) ;
   free(aaseq) ; 
   free(codonmax) ;
}

int codon_aa2aa_index (char aa) {
   int x ;
   switch (toupper(aa)) {
   case 'A' : x = 0 ; break ;
   case 'C' : x = 1 ; break ;
   case 'D' : x = 2 ; break ;
   case 'E' : x = 3 ; break ;
   case 'F' : x = 4 ; break ;
   case 'G' : x = 5 ; break ;
   case 'H' : x = 6 ; break ;
   case 'I' : x = 7 ; break ;
   case 'K' : x = 8 ; break ;
   case 'L' : x = 9 ; break ;
   case 'M' : x = 10 ; break ;
   case 'N' : x = 11 ; break ;
   case 'P' : x = 12 ; break ;
   case 'Q' : x = 13 ; break ;
   case 'R' : x = 14 ; break ;
   case 'S' : x = 15 ; break ;
   case 'T' : x = 16 ; break ;
   case 'V' : x = 17 ; break ;
   case 'W' : x = 18 ; break ;
   case 'Y' : x = 19 ; break ;
   case '*' : x = 20 ; break ;
   default : 
     printf ("ERROR: in codon_aa2aa_index(), aa=%c\n", aa) ; 
     exit (1);
   }
   return x ;
}

char codon_aa_index2aachar (int idx) {
   char x ;
   switch (idx) {
   case 0  : x ='A' ; break ;
   case 1  : x ='C' ; break ;
   case 2  : x ='D' ; break ;
   case 3  : x ='E' ; break ;
   case 4  : x ='F' ; break ;
   case 5  : x ='G' ; break ;
   case 6  : x ='H' ; break ;
   case 7  : x ='I' ; break ;
   case 8  : x ='K' ; break ;
   case 9  : x ='L' ; break ;
   case 10  : x ='M' ; break ;
   case 11  : x ='N' ; break ;
   case 12  : x ='P' ; break ;
   case 13  : x ='Q' ; break ;
   case 14  : x ='R' ; break ;
   case 15  : x ='S' ; break ;
   case 16  : x ='T' ; break ;
   case 17  : x ='V' ; break ;
   case 18  : x ='W' ; break ;
   case 19  : x ='Y' ; break ;
   case 20  : x ='*' ; break ;
   default : 
     printf ("ERROR: in codon_aa_index2aachar, idx=%d\n", idx) ; 
     exit (1);
   }
   return x ;
}

int codon_codon_nt2codon_index (char aa, char cod[4]) {
  int i, j ;
  j = codon_aa2aa_index (aa) ;
  for (i = 0 ; i < codonmax[j] ; i++) 
     if (strcmp(codon_table[j][i], cod) == 0) return i ;
   printf ("ERROR: cod does not code aa. aa=%c, cod=%s\n", aa, cod) ;
   exit(1) ;
}

char codon_codon_nt2aachar (char *c) {
   int i, j ;
   char cod[4] ;
   for (j = 0 ; j < 3 ; j++) cod[j] = c[j] ; 
   cod[3] = '\0' ;
   for (j = 0 ; j < AA_NUM ; j++) 
      for (i = 0 ; i < codonmax[j] ; i++) 
         if ( strcmp(codon_table[j][i], cod) == 0 ) {
            return codon_aa_index2aachar (j) ;
         }
   printf ("ERROR: codon_codon_nt2aachar () \n") ;
   return 'N' ; // when cod codes no amino acid.
}

void codon_read_targetFreq (int argc, char *argv[]) {
/*
target format 
G GGA 0.5 
G GGC 0.1 
G GGG 0.3 
G GGT 0.
....
*/

   char aa, cod[4] ;
   double freq ;
   int i ;
   std::string s, fn ;

   for (i = 0 ; i < AA_NUM ; i++) codonmax[i] = 0 ;
   if ( setpar_s(argc, argv, "-t", stdout) != NULL ) fn = setpar_s(argc, argv, "-t", stdout) ;
   else if ( setpar_s(argc, argv, "-of-icu", stdout) != NULL ) fn = setpar_s(argc, argv, "-of-icu", stdout) ;

   else  {
       printf ("ERROR: a file name for target codon frequencies is needed for option -t.\n") ;
       exit(1) ;
   }
   std::ifstream ifs(fn.c_str()) ;
   if (!ifs.is_open()) { printf("ERROR: -t file not found.\n") ; exit(1) ; }

   while ( std::getline (ifs, s) ) {
      if (s[0] == '#') continue ;
      sscanf (s.c_str(), "%c %s %lf", &aa, cod, &freq) ;
      for (i= 0 ; i < codonmax[ codon_aa2aa_index(aa) ] ; i++) {
         if ( strcmp(codon_table[ codon_aa2aa_index(aa) ][i], cod) == 0 ) {
      	    printf ("ERROR: multiple frequencies are assigned to the same codon. aa=%c codon=%s\n", aa, cod) ;
            exit(1) ;
         }
      }
      strcpy (codon_table[ codon_aa2aa_index(aa) ][i], cod) ;
      codonmax[ codon_aa2aa_index(aa) ]++ ;
      targetFreq[ codon_aa2aa_index(aa) ][i] = freq ;
   }
   ifs.close() ; 

   if (minrate != 0.0) {
      double maxdif = 0.0, maxerr = 0.0 ;
      for (i = 0 ; i < AA_NUM ; i++) {

         int j, flag = 0 ;
         for (j = 0 ; j < codonmax[i] ; j++) 
            if (targetFreq[i][j] < minrate) { flag++ ; break ; } 
         if (flag != 0) { // if we find a rate that is < minrate, 
            double delta = minrate/(1 - minrate*codonmax[i]) ;
            for (j = 0 ; j < codonmax[i] ; j++) {  // normalization
                double x = (targetFreq[i][j] + delta)/(1.0 + codonmax[i]*delta) ; 
                if (fabs(x-targetFreq[i][j]) > maxdif) maxdif = fabs(x-targetFreq[i][j]) ;
                targetFreq[i][j] = x ;
            }
         }

         // normalzation check
         double x = 0.0 ;
         for (j = 0 ; j < codonmax[i] ; j++) x += targetFreq[i][j] ;
         if ( fabs(x-1.0) != 0.0 && maxerr < fabs(x-1.0) ) maxerr = fabs(x-1.0) ;
      }
      printf ("CodonRate: maxdif= %e maxNormalizationError= %e\n", maxdif, maxerr) ;
   }

   if (outrates == 1) {

      std::ofstream ofs("codon.freq.cu") ;
      if (!ofs.is_open()) { printf("ERROR: codon.freq.cu cannot be opened.\n") ; exit(1) ; }
      for (i = 0 ; i < AA_NUM ; i++) {
         int j ;
         for (j = 0 ; j < codonmax[i] ; j++) 
            ofs << codon_aa_index2aachar(i) << " " << codon_table[i][j] << " " << targetFreq[i][j] << std::endl ;

      }
      ofs.close() ; 
   }
}

void codon_read_targetPairFreq (int argc, char *argv[]) {
/*
target format 

G GGA A GCC 0.2
G GGA A CCC 0.2 
G GGA A GGG 0.1
....

*/

   char aa, bb, cod[4], dod[4] ;
   double prob ;
   int i, j, k, l ;
   std::string s, fn ;

   if ( setpar_s(argc, argv, "-u", stdout) != NULL ) fn = setpar_s(argc, argv, "-u", stdout) ;
   else if ( setpar_s(argc, argv, "-of-cc", stdout) != NULL ) fn = setpar_s(argc, argv, "-of-cc", stdout) ;
   else if ( setpar_s(argc, argv, "-of-ccai", stdout) != NULL ) fn = setpar_s(argc, argv, "-of-ccai", stdout) ;

   else  {
       printf ("ERROR: a file name for codon pair frequencies is needed for option -u.\n") ;
       exit(1) ;
   }
   std::ifstream ifs(fn.c_str()) ;
   if (!ifs.is_open()) { printf("ERROR: -u file not found.\n") ; exit(1) ; }

   while ( std::getline (ifs, s) ) {
      if (s[0] == '#') continue ;
      sscanf (s.c_str(), "%c %s %c %s %lf\n", &aa, cod, &bb, dod, &prob) ;
      if (prob < 0.0 || prob > 1.0) {
	       printf ("ERROR: a frequency for codon pair %c %s %c %s = %f\n", aa, cod, bb, dod, prob) ;
         exit(1) ;
      }
      if (targetPairFreq [ codon_aa2aa_index(aa) ][ codon_codon_nt2codon_index(aa, cod) ][ codon_aa2aa_index(bb) ][ codon_codon_nt2codon_index(bb, dod) ] >= 0.0  ) {
	        printf ("ERROR: multiple frequencies are assigned to the same codon pair. aa1=%c codon1=%s aa2=%c codon2=%s\n", aa, cod, bb, dod) ;
         exit(1) ;
      }
      targetPairFreq [ codon_aa2aa_index(aa) ][ codon_codon_nt2codon_index(aa, cod) ][ codon_aa2aa_index(bb) ][ codon_codon_nt2codon_index(bb, dod) ] = prob ;
   }
   ifs.close() ; 

   if (minrate != 0.0) {
      double maxdif = 0.0, maxerr = 0.0 ;
      for (i = 0 ; i < AA_NUM - 1; i++) {
         for (k = 0 ; k < AA_NUM ; k++) {
            int j, l, flag = 0 ;
            for (j = 0 ; j < codonmax[i] ; j++) 
               for (l = 0 ; l < codonmax[k]; l++) 
                  if (targetPairFreq[i][j][k][l] < minrate) { flag++ ; break ; } 

            if (flag != 0) { // if we find a rate that is < minrate, 
               double delta = minrate/(1 - minrate*codonmax[i]*codonmax[k]) ;
               for (j = 0 ; j < codonmax[i] ; j++) {
                  for (l = 0 ; l < codonmax[k]; l++) {
                     double x = (targetPairFreq[i][j][k][l] + delta)/(1.0 + delta*codonmax[i]*codonmax[k]) ; 
                     if (fabs(x-targetPairFreq[i][j][k][l]) > maxdif) maxdif = fabs(x-targetPairFreq[i][j][k][l]) ;
                     targetPairFreq[i][j][k][l] = x ;
                  }
               }

               // normalization check
               double x = 0.0 ;
               for (j = 0 ; j < codonmax[i] ; j++) 
                  for (l = 0 ; l < codonmax[k]; l++) x += targetPairFreq[i][j][k][l] ;
               if ( fabs(x-1.0) != 0.0 && maxerr < fabs(x-1.0) ) maxerr = fabs(x-1.0) ;
            }
         }
      }
      printf ("CodonPairRate: maxdif= %e maxNormalizationError= %e\n", maxdif, maxerr) ;
   }

   if (outrates == 1) {

      std::ofstream ofs("codon.freq.cpu") ;
      if (!ofs.is_open()) { printf("ERROR: codon.freq.cpu cannot be opened.\n") ; exit(1) ; }
      for (i = 0 ; i < AA_NUM - 1; i++) {
         for (k = 0 ; k < AA_NUM ; k++) {
            for (j = 0 ; j < codonmax[i] ; j++) 
               for (l = 0 ; l < codonmax[k]; l++) 
                  ofs << codon_aa_index2aachar(i) << " " << codon_table[i][j] << " " << codon_aa_index2aachar(k) << " " << codon_table[k][l] << " " << targetPairFreq[i][j][k][l] << std::endl ;

         }
      }
      ofs.close() ; 
   }
}

void codon_output_nt (int *codon_index_seq, FILE *fp) {
   int i ;
   for (i = 0 ; i < aalen ; i++) {
     fprintf(fp, "%s", codon_table[ aaseq[i] ][ codon_index_seq[i] ]) ;
   }
   fprintf(fp, "\n");
}

int codon_get_CODON_INDEX_MAX () {
   return CODON_INDEX_MAX ;
}

void codon_aaIndex2codonIndex_nt (int *codon_index_seq, char *sq) { // This naming has a problem!
   int i ;
   for (i = 0 ; i < aalen ; i++) {
     sq[i*3 + 0] = codon_table[ aaseq[i] ][ codon_index_seq[i] ][0] ;
     sq[i*3 + 1] = codon_table[ aaseq[i] ][ codon_index_seq[i] ][1] ;
     sq[i*3 + 2] = codon_table[ aaseq[i] ][ codon_index_seq[i] ][2] ;
   }
   sq[aalen*3] = '\0' ;
}

int codon_nt2codonIndex (char *c) {
   int i, j ;
   char cod[4] ;
   for (j = 0 ; j < 3 ; j++) cod[j] = c[j] ; 
   cod[3] = '\0' ;
   for (j = 0 ; j < AA_NUM ; j++) 
      for (i = 0 ; i < codonmax[j] ; i++) 
         if ( strcmp(codon_table[j][i], cod) == 0 )  return i ;
   printf ("ERROR: codon_nt2codonIndex().\n") ;
   return -1 ; // when cod codes no amino acid.
}

int codon_get_codonmax (char amino) {
   return codonmax[ codon_aa2aa_index(amino) ] ;
}

char *codon_get_ntchar () {
   return ntchar ;
}

char *codon_get_aachar () {
   return aachar ;
}

char *codon_get_triplet (char amino, int icod) {
   return codon_table[ codon_aa2aa_index(amino) ][icod] ;
}

double codon_get_CAI_value (char amino, int icod) { // a log score
   return log(relative_adapt[ codon_aa2aa_index(amino) ][icod]) ;
}

double codon_get_CPS_value (char a, int icod, char b, int jcod) { // a log score
   return log(targetPairFreq[ codon_aa2aa_index(a) ][icod][ codon_aa2aa_index(b) ][jcod]/( targetFreq[ codon_aa2aa_index(a) ][icod]*targetFreq[ codon_aa2aa_index(b) ][jcod] )) ;
}

double codon_get_numStopCodon_value (char a, int icod, char b, int jcod) {
   return numStopCodon[ codon_aa2aa_index(a) ][icod][ codon_aa2aa_index(b) ][jcod] ;
}

double codon_get_CAI4constraint (int pos)    { if (pos >= aalen) return 0.0 ; return cai4constraint[pos] ; }
double codon_get_CAI4constraintMin (int pos) { if (pos >= aalen) return 0.0 ;return cai4constraintMin[pos] ; }
double codon_get_CPB4constraint (int pos)    { if (pos >= aalen) return 0.0 ;return cpb4constraint[pos] ; }
double codon_get_CPB4constraintMin (int pos) { if (pos >= aalen) return 0.0 ;return cpb4constraintMin[pos] ; }
double codon_get_HSC4constraint (int pos)    { if (pos >= aalen) return 0.0 ;return hsc4constraint[pos] ; }
double codon_get_HSC4constraintMin (int pos) { if (pos >= aalen) return 0.0 ;return hsc4constraintMin[pos] ; }

double codon_score_cai (int *seq) {
// seq: a codon index sequence 
// ref: 10.1093/nar/gkg306
// note: stop codons can be evaluated.
   int i ;
   double sc = 0.0 ;
   for (i = 0 ; i < aalen ; i++) sc += codon_get_CAI_value (aachar[i],seq[i]) ;
   return pow(exp(sc),1.0/aalen) ;
}

double codon_score_cpb (int *seq) {
// ref: 10.1109/TCBB.2016.2542808
   int i ;
   double sc = 0.0 ;
   for (i = 0 ; i < aalen - 1 ; i++) sc += codon_get_CPS_value (aachar[i],seq[i],aachar[i+1],seq[i+1]) ;
   return sc/(aalen - 1.0) ;
}

double codon_score_hsc (int *seq) {
   int i ;
   double sc = 0.0 ;
   for (i = 0 ; i < aalen - 1 ; i++) sc += codon_get_numStopCodon_value (aachar[i],seq[i],aachar[i+1],seq[i+1]) ;
   return sc ;
}

void codon_codonIndex2aachar (int *seq) {
// seq: a codon index sequence 
   for (int i = 0 ; i < aalen ; i++) printf ("%c", codon_codon_nt2aachar (codon_table[aaseq[i]][seq[i]])) ; 
    printf ("\n") ;
}



