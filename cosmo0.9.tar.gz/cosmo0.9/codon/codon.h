double codon_get_CAI_value (char amino, int icod) ;
double codon_get_CPS_value (char a, int icod, char b, int jcod) ;
int codon_get_codonmax (char amino) ;
double codon_get_numStopCodon_value (char a, int icod, char b, int jcod) ;
double codon_get_CAI4constraint (int pos) ;
double codon_get_CAI4constraintMin (int pos) ;
double codon_get_CPB4constraint (int pos) ;
double codon_get_CPB4constraintMin (int pos) ;
double codon_get_HSC4constraint (int pos) ;
double codon_get_HSC4constraintMin (int pos) ;
void codon_init (int argc, char *argv[], FILE *fp, int *ntot) ;

void codon_post () ;
void codon_read_targetFreq (int argc, char *argv[]) ;
void codon_read_targetPairFreq (int argc, char *argv[]) ;
void codon_output_nt (int *codon_index_seq, FILE *fp) ;
int codon_aa2aa_index (char aa) ;
int codon_codon_nt2codon_index (char aa, char cod[4]) ;
int codon_get_CODON_INDEX_MAX () ;
void codon_aaIndex2codonIndex_nt (int *codon_index_seq, char *sq) ;
char codon_aa_index2aachar (int idx) ;
char codon_codon_nt2aachar (char *c) ;
int codon_nt2codonIndex (char *c) ;
char *codon_get_ntchar () ;
char *codon_get_aachar () ;
char *codon_get_triplet (char amino, int icod) ;

double codon_score_cai (int *seq) ;
double codon_score_cpb (int *seq) ;
double codon_score_hsc (int *seq) ;

void codon_codonIndex2aachar (int *seq) ;

