=======================================================================
README for COSMO (Codon Optimization Strategy with Multiple Objectives)
Ver. 0.9.0
=======================================================================
COSMO (Codon Optimization Strategy with Multiple Objectives) is a 
multicriterion codon optimization algorithm based on dynamic programming. 
Non profit, academic users can download and use COSMO. For non-academic 
or commercial use, please contact the author (A.T.).
Copyright (c) Akito Taneda, 2018.

I recommend to use the -d option, if you don't know whether you should use the -d option or not.

===========================

Installation: type "make" at the directory that has the cosmo.cc file.

===========================

 Usage: cosmo [options] -aa -f amino_acid_sequence_filename
        or
        cosmo [options] -f CDS_filename

 -t [codon frequency file]
 -u [codon pair frequency file]
 -p [forbidden nucleotide pattern] : eg -p "AAAAA|CCCCC"
 -of [CAI/CPB/HSC/wsum] : eg -of CAI maximizes CAI score.
 -max [CAI/CPB/HSC/wsum] : eg -max CAI maximizes CAI score.
 -min [CAI/CPB/HSC/wsum] : eg -min CAI minimizes CAI score.
 -cai-c [constraint value] : eg -cai-c 0.8
 -cpb-c [constraint value] : eg -cpb-c 0.0
 -hsc-c [constraint value] : eg -hsc-c 10

 Weights for the weighted sum of OFs; note: a negative value indicates minimization:
   -cai-w [a weight for wsum] : eg -cai-w 1.0
   -cpb-w [a weight for wsum] : eg -cpb-w 1.0
   -hsc-w [a weight for wsum] : eg -hsc-w 1.0

 -w4pruning : automatically set the weights for pruning.
 -pruningList : a score vector list for pruning is read from stdin.
 -d or -dupliCheck : duplicate score vectors are deleted during the recurrence computation.
 -minrate [rate] : specify a minimum rate for f(c_i)/f(lambda(c_i)). If a zero or a very small value (causes overflow in log) is found in codon frequencies and/or codon pair frequencies, this option should be used. This option adds [rate] to each of all codons of an amino acid, then normalizes them.
 -outrates : output codon rates and/or codon pair rates.

 Automatic determination of constraints.
 If -???-constFact is specified, max and min values for the OF are used to automatically determining the constraints.  Eg if -cai-constFact 0.8 is specified for maximization, ([max CAI] - [min CAI])*0.8+[min CAI] is used as the constraint.  In addition, if -iconstFact is also specified, an OF value of the solution in the pruning list is used as the [max] or [min] value in the automatic determination of the constraint (according to maximization or minimization).
 -cai-constFact [factor]
 -cpb-constFact [factor]
 -hsc-constFact [factor]
 -iconstFact [solution in the pruning list] : eg -constFact 1 indicates the 1st solution in the list.

 -simpleMaxima : for debugging.
 -verboseOut : output #solutions deleted by the pruning. For debugging.

===========================

The followings are the commands to reproduce the results presented in the COSMO paper.
If you would like to perform the optimization without forbidden sequence motifs, 
please delete "-p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT'" from the command, then run.

# maximize CAI&CPB WITHOUT constraints
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu -of CAI -of CPB -constOFF -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT'

# maximize CAI&HSC WITHOUT constraints (-d option is specified to avoid multiple identical score vectors.)
./cosmo -aa -f example.aa -t yeast.cu -of CAI -of HSC  -constOFF -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' -d

# maximize CPB&HSC WITHOUT constraints (-d option is specified to avoid multiple identical score vectors.)
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu -of CPB -of HSC  -constOFF -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' -d


# Designs with constraints:
# To compute the lower bounds of CAI&CPB, an additional weighted-sum unicriterion run is performed.

# maximize CAI&CPB WITH the constraints
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu  -w4pruning -of wsum -cai-w 0.5 -cpb-w 0.5 -hsc-w 0.0 -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' > outf
sed -n -e "s/wsumScoreVec: //p" outf > pruningList
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu -of CAI -of CPB -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' -iconstFact 1 -cai-constFact 0.9 -cpb-constFact 0.9 -pruningList < pruningList

# maximize CAI&HSC WITH the constraints
./cosmo -aa -f example.aa -t yeast.cu -w4pruning -of wsum -cai-w 0.5 -cpb-w 0.0 -hsc-w 0.5 -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' > outf
sed -n -e "s/wsumScoreVec: //p" outf > pruningList
./cosmo -aa -f example.aa -t yeast.cu -of CAI -of HSC -iconstFact 1 -cai-constFact 0.9 -hsc-constFact 0.9 -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' -d -pruningList < pruningList

# maximize CPB&HSC WITH the constraints
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu -w4pruning -of wsum -cai-w 0.0 -cpb-w 0.5 -hsc-w 0.5 -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' > outf
sed -n -e "s/wsumScoreVec: //p" outf > pruningList
./cosmo -aa -f example.aa -t yeast.cu -u yeast.cpu -of CPB -of HSC -iconstFact 1 -cpb-constFact 0.9 -hsc-constFact 0.9 -p 'GACGTC|AAAAA|CCCCC|GGGGG|TTTTT' -d -pruningList < pruningList
