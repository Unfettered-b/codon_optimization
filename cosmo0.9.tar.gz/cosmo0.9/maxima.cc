#include <iostream>
#include <list>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>

#include "maxima.h"
/*
Bentley, Jon Louis, 
"Multidimensional divide-and-conquer",
Communications of the ACM, 214-229, (1980).

Two dimensional version.
*/

void sorted_splice (list<score> &lst, list<score> &lstL, list<score> &lstH) {
// Merge lstL and lstH in such a way that of[0] & of[1] are lexicographically sorted in lst.
// At the beginning, lst is assumed to be empty.
// It is assumed that lstL and H have already sorted in lexicographical order.
   list<score>::iterator iL = lstL.begin(), iH = lstH.begin(), it ;
   while ( iL != lstL.end() && iH != lstH.end() ) {
      if (*iL < *iH) { 
         it = iH ; it++; 
         lst.splice (lst.end(), lstH, iH) ;
         iH = it ;
      } else {
         it = iL ; it++; 
         lst.splice (lst.end(), lstL, iL) ; 
         iL = it ;
      }
   }
   if (iL != lstL.end()) lst.splice (lst.end(), lstL) ;
   else if (iH != lstH.end()) lst.splice (lst.end(), lstH) ;
}

void singleOF (list<score> &lst) { 
// Output min. solution(s) (the other elements in lst are erased). Degenerate minimum solutions are OK.
// lst should be sorted in ascending order of sc[0].
   list<score>::iterator it ;
   double max = lst.begin()->get(0) ; // this should be located at next to the following line.
   if ( lst.size() == 1 || lst.empty() ) return ;

   for (it = lst.begin() ; it != lst.end() ; ) 
      if (it->get(0) < max) it = lst.erase (it) ;
      else it++ ;
}

void twoOFs (list<score> &lst) { // sweepA
// Output non-dominated solutions in lst (the other elements are erased).
// lst should be sorted in lexicographic order of sc[0] & sc[1].
// Solutions sharing exactly the same vector values (sc[0]&sc[1]) are correctly processed by this function.
   list<score>::iterator it=lst.begin(), pre ;
   if (lst.empty()) return ;
   double max = it->get(1) ; pre = it ;
   for (it = lst.begin() ; it != lst.end() ; ) 
      if (it->get(1) > max) { max = it->get(1) ; pre = it ; it++ ; }
      else if (it->get(1) == max && pre->get(0) == it->get(0) ) it++; // Do nothing. This makes sense if exactly the same solutions exist. 
      else it = lst.erase (it) ; 
}

void simpleComparison4Merge (list<score> &lstA, list<score> &lstB, int nof) {
// lstB elements are erased if dominated by an lstA element.
// The dominace is evaluated in accordance with sc[0] to sc[nof-1].
   list<score>::iterator it, jt ;
   if ( lstA.empty() || lstB.empty() ) return ;
   for (it = lstA.begin() ; it != lstA.end() ; it++) {
      for (jt = lstB.begin() ; jt != lstB.end() ; ) {
         int n = 0, m = 0, i ;
         for (i = 0 ; i < nof ; i++) {
            if ( it->get(i) >= jt->get(i) ) n++ ;
            if ( it->get(i) != jt->get(i) ) m++ ;
         }
         if (n == nof && m != 0) jt = lstB.erase (jt) ; 
         else jt++ ;
      }
   }
}